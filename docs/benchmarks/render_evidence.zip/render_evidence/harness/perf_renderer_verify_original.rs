#![allow(dead_code)]
use portfolio::{appearance, document, i18n, platform};
#[path = "/workspace/scratch/c647e3b64d9b/perf_render_baseline/src/render.rs"]
mod reference;
use document::Color;
use portfolio::render::{Painter, Rect};

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u32 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0 as u32
    }
    fn number(&mut self, low: f32, high: f32) -> f32 {
        low + (high - low) * ((self.next() & 0xffff) as f32 / 65535.)
    }
    fn rect(&mut self) -> Rect {
        Rect::new(self.number(-25., 50.), self.number(-20., 40.), self.number(0., 150.), self.number(0., 100.))
    }
}

fn old(r: Rect) -> reference::Rect {
    reference::Rect::new(r.x, r.y, r.w, r.h)
}

fn compare(kind: &str, index: usize, before: &platform::Frame, after: &platform::Frame, case: &str) {
    if let Some((i, (a,b))) = before.pixels.iter().zip(&after.pixels).enumerate().find(|(_, (a,b))|a!=b) {
        panic!("{kind} case {index} differs at {},{}: {a:06x} -> {b:06x}; {case}", i % before.width as usize, i / before.width as usize);
    }
}

fn main() {
    let mut rng = Rng(0x20261115_6ed7c0de);
    let scales = [0.5, 0.75, 1., 1.25, 1.5, 2., 2.75];
    let opacities = [0., 0.17, 0.5, 0.998, 0.999, 1., 1.3, -0.3];
    for index in 0..2000 {
        let scale = scales[index % scales.len()];
        let mut before = reference::Painter::new(117, 93, scale, 0x364759);
        let mut after = Painter::new(117, 93, scale, 0x364759);
        for pixel in &mut before.frame.pixels { *pixel = rng.next() & 0xffffff; }
        after.frame.pixels.clone_from(&before.frame.pixels);
        let clip = if index % 4 == 0 { Rect::new(0., 0., 117. / scale, 93. / scale) } else { rng.rect() };
        before.clip = old(clip);
        after.clip = clip;
        let limit = (index % 3 == 0).then(|| rng.rect());
        before.limit = limit.map(old);
        after.limit = limit;
        let r = rng.rect();
        let width = rng.next() % 39 + 1;
        let height = rng.next() % 31 + 1;
        let mut pixels: Vec<Color> = (0..width * height).map(|_| {
            let c = rng.next();
            Color::rgba((c>>24) as u8,(c>>16) as u8,(c>>8) as u8, if index % 2 == 0 { 255 } else { c as u8 })
        }).collect();
        if index % 5 == 0 { pixels.fill(Color::rgba((index % 256) as u8, 72, 173, (index * 13 % 256) as u8)); }
        let opacity = opacities[index % opacities.len()];
        let gray = index % 3 == 0;
        before.image(old(r), width, height, &pixels, gray, opacity);
        after.image(r, width, height, &pixels, gray, opacity);
        compare("image", index, &before.frame, &after.frame, &format!("r={r:?} scale={scale} clip={clip:?} limit={limit:?} size={width}x{height} opacity={opacity} gray={gray}"));
    }
    println!("image: 2000 exact RGBA/grayscale/opacity/clip/DPI comparisons passed");
    for index in 0..2000 {
        let scale = scales[index % scales.len()];
        let mut before = reference::Painter::new(117, 93, scale, 0x364759);
        let mut after = Painter::new(117, 93, scale, 0x364759);
        for pixel in &mut before.frame.pixels { *pixel = rng.next() & 0xffffff; }
        after.frame.pixels.clone_from(&before.frame.pixels);
        let clip = if index % 4 == 0 { Rect::new(0., 0., 117. / scale, 93. / scale) } else { rng.rect() };
        before.clip = old(clip);
        after.clip = clip;
        let limit = (index % 3 == 0).then(|| rng.rect());
        before.limit = limit.map(old);
        after.limit = limit;
        let r = rng.rect();
        let radius = if index % 7 == 0 { 0. } else { rng.number(-2., 32.) };
        let opacity = opacities[index % opacities.len()];
        before.soft_shadow(old(r), radius, opacity);
        after.soft_shadow(r, radius, opacity);
        compare("shadow", index, &before.frame, &after.frame, &format!("r={r:?} scale={scale} clip={clip:?} limit={limit:?} radius={radius} opacity={opacity}"));
    }
    println!("shadow: 2000 exact radius/opacity/clip/DPI comparisons passed");
}
