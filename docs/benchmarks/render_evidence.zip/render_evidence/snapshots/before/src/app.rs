//! Application commands, layout and interaction state. No operating-system handles.
use crate::{
    appearance::{Accent, Appearance},
    demo,
    document::{self, Brush, BrushKind, Color, Document},
    i18n::Language,
    motion::Reveal,
    platform::{
        self, Answer, Effect, Event, FileKind, Frame, Modifiers, MouseButton, NativeApp, TextAlign,
        UiFont,
    },
    render::{hex, hsv, parse_hex, rgb, to_hsv, Painter, Rect, Theme},
};
use std::{
    collections::VecDeque,
    fs,
    path::PathBuf,
    sync::mpsc::{self, Receiver},
    time::{Duration, Instant},
};

#[cfg(test)]
#[path = "app_tests.rs"]
mod tests;

const PALETTE: [u32; 8] = [
    0x242b25, 0xf1e9d2, 0xd84d38, 0x5d6a43, 0xc8aa69, 0x365ad7, 0xd3e98a, 0xc297a0,
];
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Tool {
    Brush,
    Eraser,
    Fill,
    Picker,
    Line,
    Rectangle,
    Ellipse,
    Hand,
}
impl Tool {
    fn info(self) -> (&'static str, &'static str, &'static str) {
        match self {
            Self::Brush => ("brush", "Кисть", "B"),
            Self::Eraser => ("eraser", "Ластик", "E"),
            Self::Fill => ("fill", "Заливка", "G"),
            Self::Picker => ("picker", "Пипетка", "I"),
            Self::Line => ("line", "Линия", "L"),
            Self::Rectangle => ("rect", "Прямоугольник", "R"),
            Self::Ellipse => ("ellipse", "Эллипс", "O"),
            Self::Hand => ("hand", "Перемещение", "H"),
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum ToolPanel {
    Brush,
    Eraser,
    Shapes,
}

impl ToolPanel {
    fn for_tool(tool: Tool) -> Option<Self> {
        match tool {
            Tool::Brush => Some(Self::Brush),
            Tool::Eraser => Some(Self::Eraser),
            Tool::Line | Tool::Rectangle | Tool::Ellipse => Some(Self::Shapes),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
struct ToolSettings {
    kind: BrushKind,
    size: f32,
    opacity: f32,
    hardness: f32,
    flow: f32,
    spacing: f32,
    angle: f32,
    scatter: f32,
}
impl ToolSettings {
    fn from_brush(b: Brush) -> Self {
        Self {
            kind: b.kind,
            size: b.size,
            opacity: b.opacity,
            hardness: b.hardness,
            flow: b.flow,
            spacing: b.spacing,
            angle: b.angle,
            scatter: b.scatter,
        }
    }
    fn apply(self, b: &mut Brush) {
        b.kind = self.kind;
        b.size = self.size;
        b.opacity = self.opacity;
        b.hardness = self.hardness;
        b.flow = self.flow;
        b.spacing = self.spacing;
        b.angle = self.angle;
        b.scatter = self.scatter;
    }
    fn preset(kind: BrushKind, erase: bool) -> Self {
        let (size, hardness, flow, spacing, angle, scatter) = match kind {
            BrushKind::Ink => (if erase { 40. } else { 24. }, 1., 1., 0.12, 0., 0.),
            BrushKind::Soft => (80., 0.1, 0.65, 0.1, 0., 0.),
            BrushKind::Marker => (40., 0.9, 0.8, 0.1, 12., 0.),
            BrushKind::Pencil => (5., 0.9, 0.8, 0.12, 0., 0.),
            BrushKind::Charcoal => (36., 0.5, 0.8, 0.18, 10., 0.05),
            BrushKind::Chalk => (28., 0.8, 0.9, 0.18, 0., 0.),
            BrushKind::Airbrush => (120., 0.05, 0.45, 0.12, 0., 0.),
            BrushKind::Calligraphy => (36., 1., 1., 0.08, 40., 0.),
            BrushKind::Spray => (72., 0.7, 0.8, 0.2, 0., 0.1),
            BrushKind::Flat => (48., 0.9, 0.9, 0.12, 20., 0.),
        };
        Self {
            kind,
            size,
            opacity: 1.,
            hardness,
            flow,
            spacing,
            angle,
            scatter,
        }
    }
}
const BRUSH_NAMES: [&str; 10] = [
    "Тушь",
    "Мягкая",
    "Маркер",
    "Карандаш",
    "Уголь",
    "Мел",
    "Аэрограф",
    "Каллиграфия",
    "Брызги",
    "Плоская",
];

impl PortfolioApp {
    fn draw_editor(&mut self, p: &mut Painter) {
        // Modal surfaces own a separate control list. Their focus indices must
        // never highlight unrelated controls in the editor underneath.
        let overlay_input = if self.overlay != Overlay::None {
            let input = (self.focus, self.hover, self.pending_focus);
            self.focus = None;
            self.hover = None;
            self.pending_focus = None;
            Some(input)
        } else {
            None
        };
        let t = Theme::with_accent(self.dark, self.accent);
        let (w, h) = (self.w(), self.h());
        let stage = self.stage();
        p.rect(Rect::new(0., 64., w, h - 64.), t.workspace);
        // Quiet dotted work surface, separate from document pixels.
        let dot = if self.dark { 0x252525 } else { 0xbfbfbf };
        for y in (88..h as i32).step_by(24) {
            for x in (stage.x as i32 + 16..(stage.x + stage.w) as i32).step_by(24) {
                p.rect(Rect::new(x as f32, y as f32, 1., 1.), dot);
            }
        }
        p.clip = stage;
        let c = self.canvas();
        p.rounded(
            Rect::new(c.x - 7., c.y + 9., c.w + 14., c.h + 6.),
            4.,
            if self.dark { 0x090909 } else { 0xb9b9b9 },
        );
        for yy in ((c.y.max(stage.y) - c.y) / 12.).floor() as i32
            ..((c.y + c.h).min(stage.y + stage.h) - c.y).ceil() as i32 / 12 + 1
        {
            for xx in ((c.x.max(stage.x) - c.x) / 12.).floor() as i32
                ..((c.x + c.w).min(stage.x + stage.w) - c.x).ceil() as i32 / 12 + 1
            {
                let r = Rect::new(
                    (c.x + xx as f32 * 12.).max(c.x),
                    (c.y + yy as f32 * 12.).max(c.y),
                    12_f32.min(c.w - xx as f32 * 12.),
                    12_f32.min(c.h - yy as f32 * 12.),
                );
                p.rect(
                    r,
                    if (xx + yy) % 2 == 0 {
                        0xe0e0e0
                    } else {
                        0xf4f4f4
                    },
                );
            }
        }
        let damage = self.doc.take_paint_damage();
        if self.composite_dirty
            || self.composite.len() != (self.doc.width * self.doc.height) as usize
        {
            self.composite.resize(
                (self.doc.width * self.doc.height) as usize,
                Color::TRANSPARENT,
            );
            self.doc.composite_into(&mut self.composite);
            self.composite_dirty = false;
        } else if let Some(bounds) = damage {
            if !self.doc.composite_region_into(&mut self.composite, bounds) {
                self.doc.composite_into(&mut self.composite);
            }
        }
        p.image(
            c,
            self.doc.width,
            self.doc.height,
            &self.composite,
            self.grayscale,
            1.,
        );
        if self.grid {
            let step = (100. * self.zoom).max(12.);
            let color = if self.dark { 0x686868 } else { 0x858585 };
            let mut x = c.x;
            while x < c.x + c.w {
                p.line(x, c.y, x, c.y + c.h, 0.5, color);
                x += step;
            }
            let mut y = c.y;
            while y < c.y + c.h {
                p.line(c.x, y, c.x + c.w, y, 0.5, color);
                y += step;
            }
        }
        if self.brush.mirror {
            let x = c.x + c.w / 2.;
            let mut y = c.y;
            while y < c.y + c.h {
                p.line(x, y, x, (y + 5.).min(c.y + c.h), 1., 0xaaaaaa);
                y += 10.;
            }
        }
        if let Drag::Shape { x, y, ex, ey } = self.drag {
            let (x0, y0, x1, y1) = (
                self.view_x + x * self.zoom,
                self.view_y + y * self.zoom,
                self.view_x + ex * self.zoom,
                self.view_y + ey * self.zoom,
            );
            let color = rgb(self.brush.color);
            let width = (self.brush.size * self.zoom).clamp(1., 40.);
            match self.tool {
                Tool::Line => p.line(x0, y0, x1, y1, width, color),
                Tool::Rectangle => p.polyline(
                    &[(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)],
                    width,
                    color,
                ),
                Tool::Ellipse => {
                    let (cx, cy, rx, ry) = (
                        (x0 + x1) / 2.,
                        (y0 + y1) / 2.,
                        (x1 - x0).abs() / 2.,
                        (y1 - y0).abs() / 2.,
                    );
                    let pts: Vec<_> = (0..=96)
                        .map(|i| {
                            let a = i as f32 * std::f32::consts::TAU / 96.;
                            (cx + rx * a.cos(), cy + ry * a.sin())
                        })
                        .collect();
                    p.polyline(&pts, width, color);
                }
                _ => {}
            }
        }
        if stage.contains(self.pointer.0, self.pointer.1)
            && c.contains(self.pointer.0, self.pointer.1)
            && self.overlay == Overlay::None
            && self.tool_popup.is_none()
            && !self.canvas_obscured(self.pointer.0, self.pointer.1)
            && !self.space
            && matches!(self.tool, Tool::Brush | Tool::Eraser)
        {
            let r = (self.brush.size * self.zoom / 2.).max(2.);
            p.circle(self.pointer.0, self.pointer.1, r + 1., 0x111111, false);
            p.circle(self.pointer.0, self.pointer.1, r, 0xf5f5f5, false);
        }
        p.clip = Rect::new(0., 0., w, h);
        // Application header.
        p.rect(Rect::new(0., 0., w, 64.), t.base);
        let brand = self.brand_rect();
        if self.overlay == Overlay::File || brand.contains(self.pointer.0, self.pointer.1) {
            p.rounded(brand, 4., t.raised);
        }
        self.control(brand, Action::File, "Portfolio · меню проекта", true);
        p.icon(Rect::new(20., 19., 26., 26.), "star", t.accent);
        p.text(
            Rect::new(54., 10., 180., 42.),
            "Portfolio",
            23.,
            t.text,
            true,
            false,
            TextAlign::Left,
        );
        let titlew = (w - 570.).max(125.);
        p.circle(
            286.,
            32.,
            3.,
            if self.dirty() { t.accent } else { t.muted },
            true,
        );
        p.label_raw(
            299.,
            21.,
            titlew,
            format!(
                "{}{}",
                self.doc.title,
                if self.dirty() { "  ·" } else { "" }
            ),
            13.,
            t.text,
        );
        let bx = w - 347.;
        self.button(
            p,
            Rect::new(bx + 94., 16., 30., 32.),
            Action::Help,
            "?",
            None,
            false,
            true,
            false,
        );
        self.icon_button(
            p,
            Rect::new(bx + 132., 16., 32., 32.),
            Action::Theme,
            "sun",
            if self.dark {
                "Тема «Бумага»"
            } else {
                "Тема «Графит»"
            },
            false,
            true,
        );
        self.icon_button(
            p,
            Rect::new(w - 179., 18., 28., 28.),
            Action::Settings,
            "settings",
            "Настройки внешнего вида · Ctrl+,",
            self.overlay == Overlay::Settings,
            true,
        );
        self.button(
            p,
            Rect::new(w - 146., 16., 126., 32.),
            Action::Export,
            "Экспорт",
            Some("export"),
            false,
            !self.busy,
            true,
        );
        if !self.focused_mode || self.chrome_motion.active() {
            let hidden = self.focused_mode;
            self.focused_mode = false;
            self.begin_reveal(p, self.top_tools_rect(), 0);
            self.draw_top_tools(p);
            self.end_reveal(p);
            self.begin_reveal(p, self.right_panel_rect(), 0);
            self.draw_panel(p);
            self.end_reveal(p);
            self.focused_mode = hidden;
            if hidden {
                self.controls.retain(|c| c.rect.y < 64.);
            }
        }
        self.draw_popup_layer(p);
        let label = if self.busy {
            self.status.clone()
        } else if let Some(i) = self.hover {
            self.controls
                .get(i)
                .map(|c| c.label.clone())
                .unwrap_or_default()
        } else if Instant::now() < self.status_until {
            self.status.clone()
        } else {
            format!(
                "{} × {} px  ·  {} сл.  ·  {}",
                self.doc.width,
                self.doc.height,
                self.doc.layers.len(),
                self.tool.info().1
            )
        };
        p.label(299., 39., titlew, label, 10., t.muted);
        if self.overlay != Overlay::None {
            if let Some((focus, hover, pending_focus)) = overlay_input {
                self.focus = focus;
                self.hover = hover;
                self.pending_focus = pending_focus;
            }
            self.draw_animated_overlay(p);
        }
    }
    fn draw_top_tools(&mut self, p: &mut Painter) {
        let t = Theme::with_accent(self.dark, self.accent);
        let bar = self.top_tools_rect();
        self.floating_surface(p, bar, "Инструменты и масштаб");
        p.clip = bar.inset(1.);
        self.hit_clip = Some(p.clip);
        for (family, icon, tip) in [
            (ToolPanel::Brush, "brush", "Кисть · B · нажмите для выбора"),
            (
                ToolPanel::Eraser,
                "eraser",
                "Ластик · E · нажмите для выбора",
            ),
            (
                ToolPanel::Shapes,
                self.last_shape.info().0,
                "Фигуры · L / R / O · нажмите для выбора",
            ),
        ] {
            let r = self.tool_family_rect(family);
            self.button(
                p,
                r,
                Action::ToolPanel(family),
                "",
                Some(icon),
                ToolPanel::for_tool(self.tool) == Some(family),
                !self.busy,
                false,
            );
            if let Some(c) = self.controls.last_mut() {
                c.label = tip.into();
            }
        }
        let settings_tip = match self.tool {
            Tool::Brush => "Параметры кисти · F4",
            Tool::Eraser => "Параметры ластика · F4",
            Tool::Line | Tool::Rectangle | Tool::Ellipse => "Параметры фигуры · F4",
            Tool::Fill => "Непрозрачность заливки · F4",
            _ => "Выберите кисть, ластик, фигуру или заливку",
        };
        self.icon_button(
            p,
            self.tool_settings_button_rect(),
            Action::ToolProperties,
            "gear",
            settings_tip,
            self.tool_settings_visible(),
            self.tool_has_properties(),
        );
        let x = bar.x + 192.;
        p.rect(Rect::new(x - 9., 94., 1., 20.), t.border);
        for (i, tool) in [Tool::Fill, Tool::Picker, Tool::Hand]
            .into_iter()
            .enumerate()
        {
            let (icon, label, key) = tool.info();
            self.icon_button(
                p,
                Rect::new(x + i as f32 * 40., 88., 36., 32.),
                Action::Tool(tool),
                icon,
                &format!("{label} · {key}"),
                self.tool == tool,
                !self.busy,
            );
        }
        let modes = x + 128.;
        p.rect(Rect::new(modes - 9., 94., 1., 20.), t.border);
        for (i, (action, icon, tip, selected)) in [
            (
                Action::Mirror,
                "mirror",
                "Зеркальная кисть · M",
                self.brush.mirror,
            ),
            (Action::Value, "tone", "Просмотр тона · V", self.grayscale),
            (Action::Grid, "grid", "Сетка · Ctrl+'", self.grid),
        ]
        .into_iter()
        .enumerate()
        {
            self.icon_button(
                p,
                Rect::new(modes + i as f32 * 40., 88., 36., 32.),
                action,
                icon,
                tip,
                selected,
                true,
            );
        }
        for (offset, action, icon, label, enabled) in [
            (
                460.,
                Action::Undo,
                "undo",
                "Отменить · Ctrl+Z",
                self.doc.can_undo(),
            ),
            (
                496.,
                Action::Redo,
                "redo",
                "Повторить · Ctrl+Shift+Z",
                self.doc.can_redo(),
            ),
        ] {
            self.icon_button(
                p,
                Rect::new(bar.x + offset, 88., 32., 32.),
                action,
                icon,
                label,
                false,
                enabled,
            );
        }
        let ux = bar.x + bar.w - 168.;
        p.rect(Rect::new(ux - 9., 94., 1., 20.), t.border);
        self.icon_button(
            p,
            Rect::new(ux, 88., 28., 32.),
            Action::ZoomOut,
            "minus",
            "Уменьшить масштаб · −",
            false,
            true,
        );
        self.button(
            p,
            Rect::new(ux + 32., 88., 56., 32.),
            Action::Actual,
            &format!("{:.0}%", self.zoom * 100.),
            None,
            false,
            true,
            false,
        );
        if let Some(c) = self.controls.last_mut() {
            c.label = "Масштаб 100% · 1".into();
        }
        self.icon_button(
            p,
            Rect::new(ux + 92., 88., 28., 32.),
            Action::ZoomIn,
            "plus",
            "Увеличить масштаб · +",
            false,
            true,
        );
        self.icon_button(
            p,
            Rect::new(ux + 128., 88., 32., 32.),
            Action::Fit,
            "fit",
            "Вписать холст · 0",
            false,
            true,
        );
        self.hit_clip = None;
        p.clip = Rect::new(0., 0., self.w(), self.h());
    }

    fn draw_tool_popup(&mut self, p: &mut Painter) {
        let (Some(family), Some(r)) = (self.tool_popup, self.tool_popup_rect()) else {
            return;
        };
        let t = Theme::with_accent(self.dark, self.accent);
        let visible = self.motion_hit_clip.map_or(r, |clip| r.intersection(clip));
        p.frame
            .texts
            .retain(|v| !visible.intersects(Rect::new(v.x, v.y, v.width, v.height)));
        for c in &mut self.controls {
            if c.hit.intersects(r) {
                c.enabled = false;
            }
        }
        let anchor = self.tool_family_rect(family);
        self.dropdown_surface(p, r, anchor.x + anchor.w / 2., "Выбор инструмента");
        p.clip = r.inset(1.);
        self.hit_clip = Some(p.clip);
        self.icon_button(
            p,
            Rect::new(r.x + r.w - 36., r.y + 12., 28., 28.),
            Action::CloseToolPanel,
            "close",
            "Закрыть выбор · Esc",
            false,
            true,
        );
        let shapes = family == ToolPanel::Shapes;
        let start = if shapes {
            0
        } else {
            self.brush_page.min(2) * 4
        };
        let count = if shapes { 3 } else { (10 - start).min(4) };
        for slot in 0..count {
            let i = start + slot;
            let card = Rect::new(
                r.x + 8. + slot as f32 * if shapes { 112. } else { 104. },
                r.y + 8.,
                if shapes { 104. } else { 96. },
                52.,
            );
            let shape = [Tool::Line, Tool::Rectangle, Tool::Ellipse][slot.min(2)];
            let label = if shapes {
                shape.info().1
            } else {
                BRUSH_NAMES[i]
            };
            let selected = if shapes {
                self.tool == shape
            } else {
                self.brush.kind.index() as usize == i
            };
            self.button(
                p,
                card,
                if shapes {
                    Action::Shape(shape)
                } else {
                    Action::Brush(i as u8)
                },
                "",
                None,
                selected,
                !self.busy,
                false,
            );
            if let Some(c) = self.controls.last_mut() {
                c.label = label.into();
            }
            if shapes {
                p.icon(
                    Rect::new(card.x + 36., card.y + 3., 32., 30.),
                    shape.info().0,
                    t.text,
                );
            } else {
                let key = i + if self.dark { 0 } else { 10 };
                if self.brush_samples[key].is_none() {
                    self.brush_samples[key] = Some(Self::brush_sample(
                        ToolSettings::preset(BrushKind::from_index(i as u8), false),
                        t.text,
                    ));
                }
                if let Some(sample) = &self.brush_samples[key] {
                    p.image(
                        Rect::new(card.x + 3., card.y + 3., card.w - 6., 30.),
                        112,
                        40,
                        sample,
                        false,
                        1.,
                    );
                }
            }
            p.text(
                Rect::new(card.x + 3., card.y + 31., card.w - 6., 19.),
                label,
                10.,
                t.text,
                false,
                false,
                TextAlign::Center,
            );
        }
        if !shapes {
            self.icon_button(
                p,
                Rect::new(r.x + 8., r.y + 66., 28., 24.),
                Action::BrushPage(-1),
                "left",
                "Предыдущая страница",
                false,
                self.brush_page > 0,
            );
            self.icon_button(
                p,
                Rect::new(r.x + 44., r.y + 66., 28., 24.),
                Action::BrushPage(1),
                "right",
                "Следующая страница",
                false,
                self.brush_page < 2,
            );
            p.label(
                r.x + 80.,
                r.y + 70.,
                70.,
                format!("{} / 3", self.brush_page + 1),
                10.,
                t.muted,
            );
        }
        self.hit_clip = None;
        p.clip = Rect::new(0., 0., self.w(), self.h());
    }

    fn draw_panel(&mut self, p: &mut Painter) {
        let t = Theme::with_accent(self.dark, self.accent);
        let (w, h) = (self.w(), self.h());
        let panel = self.right_panel_rect();
        let x = panel.x;
        let sx = x + 20.;
        let sw = 248.;
        self.floating_surface(p, panel, "Цвет и слои");
        self.button(
            p,
            Rect::new(x + 12., panel.y + 10., 128., 30.),
            Action::Inspector(false),
            "Цвет",
            None,
            !self.inspector_layers,
            true,
            false,
        );
        self.button(
            p,
            Rect::new(x + 148., panel.y + 10., 128., 30.),
            Action::Inspector(true),
            "Слои",
            None,
            self.inspector_layers,
            true,
            false,
        );
        let off = if self.inspector_layers {
            0.
        } else {
            self.panel_scroll.clamp(0., (782. - h).max(0.))
        };
        let offset = if self.inspector_layers { 393. } else { 149. };
        let yy = |v: f32| v - offset - off;
        p.clip = Rect::new(x + 1., panel.y + 1., panel.w - 2., (h - 207.).max(0.));
        self.hit_clip = Some(p.clip);
        if !self.inspector_layers {
            p.text(
                Rect::new(sx, yy(351.), 90., 24.),
                "ЦВЕТ",
                10.,
                t.muted,
                true,
                false,
                TextAlign::Left,
            );
            p.rounded(Rect::new(sx + 108., yy(348.), 140., 28.), 4., t.raised);
            p.rounded(
                Rect::new(sx + 114., yy(354.), 16., 16.),
                4.,
                rgb(self.brush.color),
            );
            p.text(
                Rect::new(sx + 140., yy(348.), 102., 28.),
                hex(self.brush.color),
                12.,
                t.text,
                false,
                false,
                TextAlign::Left,
            );
            self.control(
                Rect::new(sx + 108., yy(348.), 140., 28.),
                Action::Hex,
                "HEX · точный цвет",
                true,
            );
            let sv = Rect::new(sx, yy(388.), sw, 84.);
            let stepsx = (sv.w * self.scale) as u32;
            let stepsy = (sv.h * self.scale) as u32;
            for py in 0..stepsy {
                for px in 0..stepsx {
                    let c = hsv(
                        self.color_h,
                        px as f32 / stepsx.max(1) as f32,
                        1. - py as f32 / stepsy.max(1) as f32,
                    );
                    p.pixel(
                        (sv.x * self.scale) as i32 + px as i32,
                        (sv.y * self.scale) as i32 + py as i32,
                        rgb(c),
                        1.,
                    );
                }
            }
            p.circle(
                sv.x + self.color_s * sv.w,
                sv.y + (1. - self.color_v) * sv.h,
                5.,
                0x141414,
                false,
            );
            p.circle(
                sv.x + self.color_s * sv.w,
                sv.y + (1. - self.color_v) * sv.h,
                3.5,
                0xffffff,
                false,
            );
            self.control(
                sv,
                Action::SV,
                "Цвет: стрелки меняют насыщенность и яркость",
                true,
            );
            let hue = Rect::new(sx, yy(485.), sw, 10.);
            for i in 0..sw as i32 {
                p.rect(
                    Rect::new(sx + i as f32, hue.y, 1., 10.),
                    rgb(hsv(i as f32 / sw * 360., 1., 1.)),
                );
            }
            let hx = sx + self.color_h / 360. * sw;
            p.rounded(Rect::new(hx - 3., hue.y - 3., 6., 16.), 3., 0xf6f6f6);
            p.rounded(
                Rect::new(hx - 1., hue.y - 1., 2., 12.),
                1.,
                rgb(hsv(self.color_h, 1., 1.)),
            );
            self.control(
                Rect::new(hue.x, hue.y - 4., hue.w, hue.h + 8.),
                Action::Hue,
                "Оттенок: стрелки меняют значение",
                true,
            );
            for (i, c) in PALETTE.iter().enumerate() {
                let r = Rect::new(sx + i as f32 * 32., yy(510.), 24., 24.);
                p.rounded(r, 4., *c);
                if rgb(self.brush.color) == *c {
                    p.rounded(r.inset(-2.), 4., t.text);
                    p.rounded(r.inset(-0.5), 4., *c);
                }
                self.control(r, Action::Swatch(i), format!("Цвет #{c:06X}"), true);
            }
            p.label(sx, yy(546.), 90., "НЕДАВНИЕ", 9., t.muted);
            for i in 0..8 {
                let r = Rect::new(sx + 88. + i as f32 * 20., yy(547.), 14., 14.);
                if let Some(c) = self.recent.get(i) {
                    let c = *c;
                    p.rounded(r, 3., rgb(c));
                    self.control(r, Action::Recent(i), format!("Недавний {}", hex(c)), true);
                } else {
                    p.rounded(r, 3., t.raised);
                }
            }
            p.rect(Rect::new(sx, yy(579.), sw, 1.), t.border);
        }
        p.text(
            Rect::new(sx, yy(585.), 155., 30.),
            format!("СЛОИ  /  {:02}", self.doc.layers.len()),
            10.,
            t.muted,
            true,
            false,
            TextAlign::Left,
        );
        self.icon_button(
            p,
            Rect::new(sx + 216., yy(584.), 32., 28.),
            Action::AddLayer,
            "plus",
            "Добавить слой · Ctrl+Shift+N",
            false,
            self.doc.layers.len() < document::MAX_LAYERS,
        );
        let opacity = self.doc.layers[self.doc.active].opacity as f32 / 255.;
        self.slider(
            p,
            Rect::new(sx, yy(615.), sw, 42.),
            Action::LayerOpacity,
            opacity,
            1.,
            "Непрозрачность слоя",
            format!("{:.0}%", opacity * 100.),
            true,
        );
        let row_top = yy(662.);
        let row_bottom = (h - 62.).max(row_top + 40.);
        let count = (((row_bottom - row_top - 40.) / 44.).floor() + 1.).max(1.) as usize;
        self.layer_scroll = self
            .layer_scroll
            .min(self.doc.layers.len().saturating_sub(count));
        for pos in 0..count {
            let n = self.doc.layers.len();
            if pos + self.layer_scroll >= n {
                break;
            }
            let i = n - 1 - pos - self.layer_scroll;
            let y = row_top + pos as f32 * 44.;
            let selected = i == self.doc.active;
            let visible = self.doc.layers[i].visible;
            let locked = self.doc.layers[i].locked;
            let r = Rect::new(sx - 8., y, sw + 16., 40.);
            if selected {
                p.rounded(r, 4., t.accent);
                p.rounded(r.inset(1.), 3., t.selected);
            }
            self.control(
                Rect::new(sx + 26., y, sw - 56., 40.),
                Action::Layer(i),
                format!("Слой: {} · F2 — имя", self.doc.layers[i].name),
                true,
            );
            self.icon_button(
                p,
                Rect::new(sx - 6., y + 7., 26., 26.),
                Action::Visible(i),
                if visible { "eye" } else { "hidden" },
                "Показать / скрыть слой",
                false,
                true,
            );
            let thumb = Rect::new(sx + 28., y + 6., 38., 28.);
            p.rounded(thumb, 4., t.workspace);
            let old = p.clip;
            p.clip = thumb;
            p.image(
                thumb,
                self.doc.width,
                self.doc.height,
                &self.doc.layers[i].pixels,
                false,
                1.,
            );
            p.clip = old;
            p.label_raw(
                sx + 77.,
                y + 8.,
                135.,
                self.doc.layers[i].name.clone(),
                12.,
                if visible { t.text } else { t.muted },
            );
            self.icon_button(
                p,
                Rect::new(sx + 220., y + 7., 26., 26.),
                Action::Lock(i),
                if locked { "lock" } else { "unlock" },
                "Заблокировать / разблокировать слой",
                false,
                true,
            );
        }
        if self.doc.layers.len() > count {
            let trackh = (row_bottom - row_top).max(10.);
            p.rounded(Rect::new(x + 278., row_top, 2., trackh), 1., t.border);
            p.rounded(
                Rect::new(
                    x + 278.,
                    row_top + trackh * self.layer_scroll as f32 / self.doc.layers.len() as f32,
                    3.,
                    (trackh * count as f32 / self.doc.layers.len() as f32).max(10.),
                ),
                1.,
                t.muted,
            );
        }
        if !self.inspector_layers && h < 782. {
            let track = Rect::new(x + 283., panel.y + 8., 2., (h - panel.y - 78.).max(20.));
            let maximum = 782. - h;
            let thumb = (track.h * track.h / (track.h + maximum)).max(24.);
            p.rounded(track, 1., t.raised);
            p.rounded(
                Rect::new(
                    track.x,
                    track.y + (track.h - thumb) * off / maximum,
                    2.,
                    thumb,
                ),
                1.,
                t.muted,
            );
        }
        p.clip = Rect::new(0., 0., w, h);
        self.hit_clip = None;
        let by = h - 52.;
        p.clip = panel.inset(1.);
        self.hit_clip = Some(panel.inset(1.));
        p.rect(Rect::new(x + 1., by - 8., 286., 43.), t.surface);
        p.rect(Rect::new(sx, by - 9., sw, 1.), t.border);
        for (i, (act, icon, tip)) in [
            (Action::Rename, "brush", "Имя слоя · F2"),
            (Action::Duplicate, "copy", "Дублировать слой"),
            (Action::Raise, "up", "Переместить слой выше"),
            (Action::Lower, "down", "Переместить слой ниже"),
            (Action::DeleteLayer, "trash", "Удалить слой · Ctrl+Delete"),
        ]
        .into_iter()
        .enumerate()
        {
            let enabled = match act {
                Action::Raise => self.doc.active + 1 < self.doc.layers.len(),
                Action::Lower => self.doc.active > 0,
                Action::DeleteLayer => self.doc.layers.len() > 1,
                _ => true,
            };
            self.icon_button(
                p,
                Rect::new(sx + i as f32 * 50., by, 40., 28.),
                act,
                icon,
                tip,
                false,
                enabled,
            );
        }
        p.clip = Rect::new(0., 0., w, h);
        self.hit_clip = None;
    }
    fn draw_tool_settings(&mut self, p: &mut Painter) {
        let t = Theme::with_accent(self.dark, self.accent);
        let r = self.tool_settings_rect();
        self.controls.clear();
        let visible = self.motion_hit_clip.map_or(r, |clip| r.intersection(clip));
        p.frame
            .texts
            .retain(|v| !visible.intersects(Rect::new(v.x, v.y, v.width, v.height)));
        let gear = self.tool_settings_button_rect();
        self.dropdown_surface(p, r, gear.x + gear.w / 2., "Параметры инструмента");
        p.clip = r.inset(1.);
        self.hit_clip = Some(p.clip);
        p.text(
            Rect::new(r.x + 20., r.y + 12., r.w - 84., 32.),
            self.tool_properties_title(),
            21.,
            t.text,
            true,
            false,
            TextAlign::Left,
        );
        self.icon_button(
            p,
            Rect::new(r.x + r.w - 44., r.y + 16., 28., 28.),
            Action::CloseToolProperties,
            "close",
            "Закрыть параметры · F4 / Esc",
            false,
            true,
        );
        let brushes = matches!(self.tool, Tool::Brush | Tool::Eraser);
        if brushes {
            p.label(
                r.x + 20.,
                r.y + 46.,
                250.,
                BRUSH_NAMES[self.brush.kind.index() as usize],
                11.,
                t.muted,
            );
            for (detail, label, x) in [(false, "Основные", 20.), (true, "Отпечаток", 164.)]
            {
                self.button(
                    p,
                    Rect::new(r.x + x, r.y + 70., 136., 28.),
                    Action::BrushDetail(detail),
                    label,
                    None,
                    self.brush_detail == detail,
                    true,
                    false,
                );
            }
            let actions = if self.brush_detail {
                vec![Action::Spacing, Action::Angle, Action::Scatter]
            } else {
                vec![
                    Action::Size,
                    Action::Opacity,
                    Action::Hardness,
                    Action::Flow,
                ]
            };
            for (i, a) in actions.into_iter().enumerate() {
                self.parameter_slider(
                    p,
                    Rect::new(r.x + 20., r.y + 112. + i as f32 * 54., r.w - 40., 46.),
                    a,
                );
            }
            if self.brush_detail {
                let sample = Self::brush_sample(ToolSettings::from_brush(self.brush), t.text);
                p.image(
                    Rect::new(r.x + 20., r.y + 284., r.w - 40., 48.),
                    112,
                    40,
                    &sample,
                    false,
                    1.,
                );
            }
            self.button(
                p,
                Rect::new(r.x + 20., r.y + 350., r.w - 40., 30.),
                Action::ResetBrush,
                "Сбросить кисть",
                None,
                false,
                !self.busy,
                false,
            );
        } else {
            if self.tool != Tool::Fill {
                self.parameter_slider(
                    p,
                    Rect::new(r.x + 20., r.y + 64., r.w - 40., 46.),
                    Action::Size,
                );
            }
            self.parameter_slider(
                p,
                Rect::new(
                    r.x + 20.,
                    r.y + if self.tool == Tool::Fill { 64. } else { 118. },
                    r.w - 40.,
                    46.,
                ),
                Action::Opacity,
            );
        }
        p.label(
            r.x + 20.,
            r.y + r.h - 30.,
            r.w - 40.,
            "Число — точный ввод · F4 / Esc — закрыть",
            10.,
            t.muted,
        );
        self.hit_clip = None;
        p.clip = Rect::new(0., 0., self.w(), self.h());
    }

    fn draw_settings(&mut self, p: &mut Painter) {
        let t = Theme::with_accent(self.dark, self.accent);
        let r = self.settings_rect();
        self.controls.clear();
        let visible = self.motion_hit_clip.map_or(r, |clip| r.intersection(clip));
        p.frame
            .texts
            .retain(|v| !visible.intersects(Rect::new(v.x, v.y, v.width, v.height)));
        self.dropdown_surface(p, r, self.w() - 165., "Настройки");
        p.clip = r.inset(1.);
        self.hit_clip = Some(p.clip);
        p.text(
            Rect::new(r.x + 20., r.y + 12., r.w - 84., 32.),
            "Настройки",
            21.,
            t.text,
            true,
            false,
            TextAlign::Left,
        );
        self.icon_button(
            p,
            Rect::new(r.x + r.w - 44., r.y + 16., 28., 28.),
            Action::CloseSettings,
            "close",
            "Закрыть настройки · Esc",
            false,
            true,
        );
        for (i, label) in ["Вид", "Текст", "Язык"].into_iter().enumerate() {
            self.button(
                p,
                Rect::new(r.x + 20. + i as f32 * 122., r.y + 52., 116., 28.),
                Action::SettingsTab(i as u8),
                label,
                None,
                self.settings_tab == i as u8,
                true,
                false,
            );
        }
        match self.settings_tab {
            1 => {
                p.label(r.x + 20., r.y + 94., 350., "Шрифт интерфейса", 11., t.muted);
                for (i, font) in UiFont::ALL.into_iter().enumerate() {
                    let card = Rect::new(
                        r.x + 20. + (i % 2) as f32 * 186.,
                        r.y + 118. + (i / 2) as f32 * 44.,
                        174.,
                        40.,
                    );
                    self.button(
                        p,
                        card,
                        Action::SetFont(font),
                        "",
                        None,
                        self.ui_font == font,
                        true,
                        false,
                    );
                    if let Some(c) = self.controls.last_mut() {
                        c.label = font.label().into();
                    }
                    p.label_raw(card.x + 10., card.y + 2., 154., font.label(), 9., t.muted);
                    let old = p.font;
                    p.font = font;
                    p.text_raw(
                        Rect::new(card.x + 10., card.y + 15., 154., 23.),
                        "Aa · 0123",
                        13.,
                        t.text,
                        false,
                        false,
                        TextAlign::Left,
                    );
                    p.font = old;
                }
                self.parameter_slider(
                    p,
                    Rect::new(r.x + 20., r.y + 350., 360., 46.),
                    Action::FontSize,
                );
                p.label(
                    r.x + 20.,
                    r.y + 408.,
                    360.,
                    "Образец текста · Portfolio 0123",
                    13.,
                    t.text,
                );
            }
            2 => {
                p.label(r.x + 20., r.y + 100., 360., "Язык интерфейса", 12., t.muted);
                for (i, language) in Language::ALL.into_iter().enumerate() {
                    let card = Rect::new(
                        r.x + 20. + (i % 2) as f32 * 186.,
                        r.y + 132. + (i / 2) as f32 * 72.,
                        174.,
                        58.,
                    );
                    self.button(
                        p,
                        card,
                        Action::SetLanguage(language),
                        "",
                        None,
                        self.language == language,
                        true,
                        false,
                    );
                    p.text_raw(
                        card,
                        language.label(),
                        17.,
                        t.text,
                        false,
                        false,
                        TextAlign::Center,
                    );
                    if let Some(c) = self.controls.last_mut() {
                        c.label = language.label().into();
                    }
                }
            }
            _ => {
                p.label(r.x + 20., r.y + 100., 360., "Тема", 11., t.muted);
                for (i, (dark, label)) in [(true, "Графит"), (false, "Бумага")]
                    .into_iter()
                    .enumerate()
                {
                    self.button(
                        p,
                        Rect::new(r.x + 20. + i as f32 * 186., r.y + 124., 174., 32.),
                        Action::SetTheme(dark),
                        label,
                        None,
                        self.dark == dark,
                        true,
                        false,
                    );
                }
                p.label(r.x + 20., r.y + 184., 360., "Акцент", 11., t.muted);
                for (i, accent) in Accent::ALL.into_iter().enumerate() {
                    let card = Rect::new(r.x + 20. + i as f32 * 73., r.y + 208., 68., 52.);
                    self.button(
                        p,
                        card,
                        Action::SetAccent(accent),
                        "",
                        None,
                        self.accent == accent,
                        true,
                        false,
                    );
                    p.circle(
                        card.x + 34.,
                        card.y + 16.,
                        7.,
                        accent.color(self.dark),
                        true,
                    );
                    p.text(
                        Rect::new(card.x + 2., card.y + 29., 64., 20.),
                        accent.label(),
                        9.,
                        t.text,
                        false,
                        false,
                        TextAlign::Center,
                    );
                    if let Some(c) = self.controls.last_mut() {
                        c.label = accent.label().into();
                    }
                }
                p.label(
                    r.x + 20.,
                    r.y + 288.,
                    360.,
                    "Анимации панелей",
                    12.,
                    t.muted,
                );
                self.button(
                    p,
                    Rect::new(r.x + 20., r.y + 316., 174., 32.),
                    Action::SetAnimations(true),
                    "Плавно",
                    None,
                    self.animations,
                    true,
                    false,
                );
                self.button(
                    p,
                    Rect::new(r.x + 206., r.y + 316., 174., 32.),
                    Action::SetAnimations(false),
                    "Без анимаций",
                    None,
                    !self.animations,
                    true,
                    false,
                );
                p.label(
                    r.x + 20.,
                    r.y + 362.,
                    360.,
                    "Учитываются настройки Windows",
                    11.,
                    t.muted,
                );
            }
        }
        p.rect(Rect::new(r.x + 20., r.y + 440., 360., 1.), t.border);
        self.button(
            p,
            Rect::new(r.x + 20., r.y + 450., 142., 30.),
            Action::ResetAppearance,
            "Сбросить вид",
            None,
            false,
            true,
            false,
        );
        p.text(
            Rect::new(r.x + 174., r.y + 450., 206., 30.),
            "Сохраняется автоматически",
            10.,
            t.muted,
            false,
            false,
            TextAlign::Right,
        );
        self.hit_clip = None;
        p.clip = Rect::new(0., 0., self.w(), self.h());
    }

    fn draw_overlay(&mut self, p: &mut Painter) {
        if self.overlay == Overlay::ToolProperties {
            self.draw_tool_settings(p);
            return;
        }
        if self.overlay == Overlay::Settings {
            self.draw_settings(p);
            return;
        }
        let t = Theme::with_accent(self.dark, self.accent);
        let (w, h) = (self.w(), self.h());
        self.controls.clear();
        self.hover = None;
        if self.overlay == Overlay::File {
            let r = self.file_menu_rect();
            p.frame.texts.retain(|v| {
                !Rect::new(v.x, v.y, v.width, v.height).contains(r.x, r.y)
                    && !(v.x < r.x + r.w
                        && v.x + v.width > r.x
                        && v.y < r.y + r.h
                        && v.y + v.height > r.y)
            });
            p.soft_shadow(r, 4., if self.dark { 0.14 } else { 0.10 });
            p.rounded(r, 4., t.surface);
            p.triangle_up(105., r.y + 1., 8., 9., t.surface);
            let items = [
                (Action::New, "Новый холст", "Ctrl+N"),
                (Action::Open, "Открыть проект…", "Ctrl+O"),
                (Action::Import, "Добавить изображение…", "Ctrl+Shift+O"),
                (Action::Save, "Сохранить", "Ctrl+S"),
                (Action::SaveAs, "Сохранить как…", "Ctrl+Shift+S"),
                (Action::Export, "Экспорт PNG…", "Ctrl+Shift+E"),
                (Action::Demo, "Открыть этюд FORM 01", ""),
                (Action::Help, "Клавиши и инструменты", "F1"),
            ];
            for (i, (a, label, key)) in items.into_iter().enumerate() {
                let item = Rect::new(r.x + 8., r.y + 8. + i as f32 * 40., r.w - 16., 36.);
                if i == self.menu_index {
                    p.rounded(item, 4., t.accent);
                    p.rounded(item.inset(1.), 3., t.selected);
                }
                p.label(item.x + 9., item.y + 7., item.w - 110., label, 12., t.text);
                p.text(
                    Rect::new(item.x + item.w - 102., item.y, 93., 36.),
                    key,
                    10.,
                    t.muted,
                    false,
                    false,
                    TextAlign::Right,
                );
                self.control(item, a, label, !self.busy);
            }
        } else {
            // Clear underlying text; dim the exact framebuffer before adding dialog content.
            p.frame.texts.clear();
            for c in &mut p.frame.pixels {
                let r = (*c >> 16 & 255) * 38 / 100;
                let g = (*c >> 8 & 255) * 38 / 100;
                let b = (*c & 255) * 38 / 100;
                *c = (r << 16) | (g << 8) | b;
            }
            let dh = if self.overlay == Overlay::New {
                390.
            } else {
                530.
            };
            let r = Rect::new((w - 540.) / 2., (h - dh) / 2., 540., dh);
            p.soft_shadow(r, 4., if self.dark { 0.14 } else { 0.10 });
            p.rounded(r, 4., t.surface);
            self.icon_button(
                p,
                Rect::new(r.x + r.w - 48., r.y + 16., 32., 32.),
                Action::Cancel,
                "close",
                "Закрыть · Escape",
                false,
                true,
            );
            if self.overlay == Overlay::New {
                p.text(
                    Rect::new(r.x + 32., r.y + 22., 430., 40.),
                    "Место для новой идеи.",
                    24.,
                    t.text,
                    true,
                    false,
                    TextAlign::Left,
                );
                p.label(
                    r.x + 32.,
                    r.y + 69.,
                    440.,
                    "Выберите формат. Остальное — ваш почерк.",
                    12.,
                    t.muted,
                );
                for (i, (label, sub)) in [
                    ("Этюд", "1200 × 840"),
                    ("Квадрат", "1080 × 1080"),
                    ("Постер", "1200 × 1600"),
                ]
                .into_iter()
                .enumerate()
                {
                    let rr = Rect::new(r.x + 32. + i as f32 * 161., r.y + 115., 152., 76.);
                    self.button(
                        p,
                        rr,
                        Action::NewPreset(i as u8),
                        label,
                        None,
                        matches!(
                            (self.new_width, self.new_height, i),
                            (1200, 840, 0) | (1080, 1080, 1) | (1200, 1600, 2)
                        ),
                        true,
                        false,
                    );
                    p.label(rr.x + 32., rr.y + 52., 120., sub, 10., t.muted);
                }
                p.label(r.x + 32., r.y + 215., 120., "Ширина / px", 11., t.muted);
                p.label(r.x + 283., r.y + 215., 140., "Высота / px", 11., t.muted);
                self.button(
                    p,
                    Rect::new(r.x + 32., r.y + 240., 225., 40.),
                    Action::NewWidth,
                    &self.new_width.to_string(),
                    None,
                    false,
                    true,
                    false,
                );
                self.button(
                    p,
                    Rect::new(r.x + 283., r.y + 240., 225., 40.),
                    Action::NewHeight,
                    &self.new_height.to_string(),
                    None,
                    false,
                    true,
                    false,
                );
                p.label(
                    r.x + 32.,
                    r.y + 300.,
                    320.,
                    "Бумага + пустой слой · до 4096 px на сторону",
                    11.,
                    t.muted,
                );
                self.button(
                    p,
                    Rect::new(r.x + 352., r.y + 330., 156., 36.),
                    Action::Create,
                    "Создать холст",
                    None,
                    false,
                    true,
                    true,
                );
            } else {
                p.text(
                    Rect::new(r.x + 32., r.y + 24., 420., 40.),
                    "Рисуйте в своём ритме.",
                    24.,
                    t.text,
                    true,
                    false,
                    TextAlign::Left,
                );
                p.label(
                    r.x + 32.,
                    r.y + 73.,
                    420.,
                    "Portfolio / Краткая карта студии",
                    12.,
                    t.muted,
                );
                let help = [
                    ("B / E / G / I", "Кисть / ластик / заливка / пипетка"),
                    ("L / R / O", "Линия / прямоугольник / эллипс"),
                    ("Пробел + движение", "Перемещение холста"),
                    ("Колесо / 0 / 1", "Масштаб / вписать / 100%"),
                    ("[ / ]", "Уменьшить / увеличить кисть"),
                    ("M / V / Tab", "Зеркало / тон / режим фокуса"),
                    ("Ctrl+Z / Ctrl+Shift+Z", "Отмена / повтор"),
                    ("Ctrl+S / Ctrl+Shift+E", "Сохранить проект / PNG"),
                    ("F6 / Shift+F6", "Фокус по элементам интерфейса"),
                    ("Enter / стрелки", "Активировать / точное изменение"),
                    ("Escape", "Отменить жест / закрыть панель"),
                ];
                for (i, (key, label)) in help.into_iter().enumerate() {
                    let y = r.y + 121. + i as f32 * 31.;
                    p.label(r.x + 32., y, 185., key, 11., t.accent);
                    p.label(r.x + 218., y, 290., label, 11., t.text);
                }
                p.label(
                    r.x + 32.,
                    r.y + 482.,
                    468.,
                    "F2 — имя слоя. Alt — временная пипетка. Цвета рисунка не зависят от темы.",
                    10.,
                    t.muted,
                );
            }
        }
    }
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Action {
    NoOp,
    File,
    New,
    Open,
    Import,
    Save,
    SaveAs,
    Export,
    Demo,
    Undo,
    Redo,
    Theme,
    Settings,
    CloseSettings,
    SetTheme(bool),
    SetFont(UiFont),
    SetAccent(Accent),
    SettingsTab(u8),
    SetLanguage(Language),
    FontSize,
    SetAnimations(bool),
    Inspector(bool),
    BrushPage(i8),
    BrushDetail(bool),
    ResetBrush,
    Hardness,
    Flow,
    Spacing,
    Angle,
    Scatter,
    ResetAppearance,
    Help,
    Focus,
    Fit,
    Actual,
    ZoomIn,
    ZoomOut,
    Tool(Tool),
    ToolProperties,
    CloseToolProperties,
    ToolPanel(ToolPanel),
    CloseToolPanel,
    Shape(Tool),
    Mirror,
    Value,
    Grid,
    Brush(u8),
    Size,
    Opacity,
    Hex,
    SV,
    Hue,
    Swatch(usize),
    Recent(usize),
    AddLayer,
    Layer(usize),
    Visible(usize),
    Lock(usize),
    LayerOpacity,
    Rename,
    Duplicate,
    DeleteLayer,
    Raise,
    Lower,
    NewPreset(u8),
    NewWidth,
    NewHeight,
    Create,
    Cancel,
}
#[derive(Clone)]
struct Control {
    rect: Rect,
    hit: Rect,
    action: Action,
    label: String,
    enabled: bool,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Overlay {
    None,
    File,
    New,
    Help,
    Settings,
    ToolProperties,
}
#[derive(Clone, Copy)]
enum Drag {
    None,
    Stroke,
    Pan {
        x: f32,
        y: f32,
        ox: f32,
        oy: f32,
    },
    Shape {
        x: f32,
        y: f32,
        ex: f32,
        ey: f32,
    },
    Slider {
        action: Action,
        rect: Rect,
        initial: f32,
    },
    Color {
        action: Action,
        rect: Rect,
        initial: Color,
        initial_h: f32,
    },
}
#[derive(Clone, Copy)]
enum Pending {
    None,
    New,
    Open,
    Demo,
    Quit,
}
enum IoMessage {
    Saved {
        path: PathBuf,
        serial: u64,
        result: Result<(), String>,
    },
    Exported(Result<(), String>),
    Loaded {
        path: PathBuf,
        result: Result<Document, String>,
    },
    Imported {
        path: PathBuf,
        result: Result<platform::ImportedImage, String>,
    },
    Recovered(Result<Document, String>),
}

pub struct PortfolioApp {
    pub doc: Document,
    pub dark: bool,
    ui_font: UiFont,
    accent: Accent,
    language: Language,
    font_size: u16,
    preferences_dirty: bool,
    animations: bool,
    system_reduced_motion: bool,
    motion_runtime: bool,
    chrome_motion: Reveal,
    popup_motion: Reveal,
    overlay_motion: Reveal,
    closing_overlay: Option<Overlay>,
    closing_popup: Option<ToolPanel>,
    motion_hit_clip: Option<Rect>,
    motion_preview: Option<f32>,
    settings_tab: u8,
    inspector_layers: bool,
    brush_page: usize,
    brush_detail: bool,
    paint_presets: [ToolSettings; 10],
    erase_presets: [ToolSettings; 10],
    brush_samples: Vec<Option<Vec<Color>>>,
    pub tool: Tool,
    brush: Brush,
    tool_popup: Option<ToolPanel>,
    paint_settings: ToolSettings,
    erase_settings: ToolSettings,
    shape_settings: ToolSettings,
    last_shape: Tool,
    color_h: f32,
    color_s: f32,
    color_v: f32,
    recent: Vec<Color>,
    width: u32,
    height: u32,
    scale: f32,
    view_x: f32,
    view_y: f32,
    zoom: f32,
    initialized: bool,
    pub focused_mode: bool,
    grayscale: bool,
    grid: bool,
    controls: Vec<Control>,
    hit_clip: Option<Rect>,
    focus: Option<usize>,
    pending_focus: Option<Action>,
    hover: Option<usize>,
    pointer: (f32, f32),
    space: bool,
    alt: bool,
    overlay: Overlay,
    menu_index: usize,
    drag: Drag,
    layer_scroll: usize,
    panel_scroll: f32,
    status: String,
    status_until: Instant,
    path: Option<PathBuf>,
    unsaved_origin: bool,
    pending: Pending,
    file_is_save: bool,
    new_width: u32,
    new_height: u32,
    serial: u64,
    last_edit: Instant,
    last_auto: Instant,
    io: Option<Receiver<IoMessage>>,
    auto_io: Option<Receiver<(u64, Result<(), String>)>>,
    document_id: u64,
    import_queue: VecDeque<PathBuf>,
    importing: bool,
    import_failures: Vec<String>,
    import_count: usize,
    auto_revision: Option<(u64, u64)>,
    last_auto_saved: Option<(u64, u64)>,
    recovery_requested: bool,
    preserve_recovery: bool,
    busy: bool,
    prefs: Option<PathBuf>,
    recovery: Option<PathBuf>,
    recover_available: bool,
    first_tick: bool,
    composite: Vec<Color>,
    composite_dirty: bool,
    title_dirty: bool,
}

impl PortfolioApp {
    fn activate(&mut self, a: Action, out: &mut Vec<Effect>) {
        let keyboard = self.focus.is_some();
        self.finish_drag();
        self.focus = None;
        if self.busy
            && !matches!(
                a,
                Action::Theme
                    | Action::ToolProperties
                    | Action::CloseToolProperties
                    | Action::Settings
                    | Action::CloseSettings
                    | Action::SetTheme(_)
                    | Action::SetFont(_)
                    | Action::SetAccent(_)
                    | Action::SettingsTab(_)
                    | Action::SetLanguage(_)
                    | Action::SetAnimations(_)
                    | Action::FontSize
                    | Action::Inspector(_)
                    | Action::ResetAppearance
                    | Action::Help
                    | Action::Focus
                    | Action::Fit
                    | Action::Actual
                    | Action::ZoomIn
                    | Action::ZoomOut
                    | Action::Cancel
                    | Action::CloseToolPanel
            )
        {
            self.feedback("Дождитесь окончания записи.");
            return;
        }
        if self.overlay == Overlay::File && a != Action::File {
            self.overlay = Overlay::None;
            self.hover = None;
        }
        if self.overlay == Overlay::ToolProperties
            && !matches!(
                a,
                Action::ToolProperties
                    | Action::CloseToolProperties
                    | Action::Size
                    | Action::Opacity
                    | Action::Hardness
                    | Action::Flow
                    | Action::Spacing
                    | Action::Angle
                    | Action::Scatter
                    | Action::BrushDetail(_)
                    | Action::ResetBrush
                    | Action::NoOp
            )
        {
            self.close_tool_settings();
            self.pending_focus = None;
        }
        if keyboard && self.overlay == Overlay::ToolProperties && a.is_brush_parameter() {
            self.pending_focus = Some(a);
        }
        if !matches!(
            a,
            Action::ToolPanel(_)
                | Action::CloseToolPanel
                | Action::Shape(_)
                | Action::Brush(_)
                | Action::BrushPage(_)
                | Action::Size
                | Action::Opacity
        ) {
            self.close_tool_popup();
        }
        match a {
            Action::NoOp => {}
            Action::File => {
                self.overlay = if self.overlay == Overlay::File {
                    Overlay::None
                } else {
                    Overlay::File
                };
                self.menu_index = 0;
                self.hover = None;
            }
            Action::New => self.request_replace(Pending::New, out),
            Action::Open => self.request_replace(Pending::Open, out),
            Action::Demo => self.request_replace(Pending::Demo, out),
            Action::Import => out.push(Effect::OpenFile(FileKind::Image)),
            Action::Save => self.save(false, out),
            Action::SaveAs => self.save(true, out),
            Action::Export => out.push(Effect::SaveFile {
                kind: FileKind::Png,
                suggested_name: format!("{}.png", self.doc.title),
            }),
            Action::Undo => {
                if self.doc.undo() {
                    self.changed();
                    self.feedback("Действие отменено");
                }
            }
            Action::Redo => {
                if self.doc.redo() {
                    self.changed();
                    self.feedback("Действие повторено");
                }
            }
            Action::Theme => {
                self.dark = !self.dark;
                self.persist_appearance(out);
                out.push(Effect::SetDarkMode(self.dark));
                self.feedback(if self.dark {
                    "Тема «Графит»"
                } else {
                    "Тема «Бумага»"
                });
            }
            Action::Settings => {
                if self.overlay == Overlay::Settings {
                    self.close_settings();
                } else {
                    self.overlay = Overlay::Settings;
                    self.controls.clear();
                    self.hover = None;
                    if keyboard {
                        self.pending_focus = Some(self.settings_focus_action());
                    }
                }
            }
            Action::CloseSettings => self.close_settings(),
            Action::SettingsTab(tab) => {
                self.settings_tab = tab.min(2);
                self.controls.clear();
                self.hover = None;
                if keyboard {
                    self.pending_focus = Some(match self.settings_tab {
                        1 => Action::SetFont(self.ui_font),
                        2 => Action::SetLanguage(self.language),
                        _ => Action::SetTheme(self.dark),
                    });
                }
            }
            Action::SetLanguage(language) => {
                self.language = language;
                self.persist_appearance(out);
                if keyboard {
                    self.pending_focus = Some(Action::SetLanguage(language));
                }
            }
            Action::SetAnimations(value) => {
                self.animations = value;
                self.persist_appearance(out);
                if keyboard {
                    self.pending_focus = Some(a);
                }
            }
            Action::Inspector(layers) => {
                self.inspector_layers = layers;
                self.focused_mode = false;
                self.panel_scroll = 0.;
                self.layer_scroll = 0;
                self.controls.clear();
            }
            Action::BrushDetail(detail) => {
                self.brush_detail = detail;
                self.controls.clear();
                if keyboard {
                    self.pending_focus = Some(if detail {
                        Action::Spacing
                    } else {
                        Action::Size
                    });
                }
            }
            Action::BrushPage(delta) => {
                self.brush_page = (self.brush_page as i32 + delta as i32).clamp(0, 2) as usize;
                self.controls.clear();
            }
            Action::ResetBrush => {
                ToolSettings::preset(self.brush.kind, self.tool == Tool::Eraser)
                    .apply(&mut self.brush);
            }
            Action::FontSize
            | Action::Hardness
            | Action::Flow
            | Action::Spacing
            | Action::Angle
            | Action::Scatter => {
                let (min, max, label, id, _) = self.parameter_info(a);
                out.push(Self::prompt(
                    id,
                    label,
                    &format!("Введите число от {min:.0} до {max:.0}."),
                    format!("{:.0}", self.parameter_value(a)),
                ));
            }
            Action::SetTheme(dark) => {
                self.dark = dark;
                out.push(Effect::SetDarkMode(dark));
                self.persist_appearance(out);
                if keyboard {
                    self.pending_focus = Some(Action::SetTheme(dark));
                }
            }
            Action::SetFont(font) => {
                self.ui_font = font;
                self.persist_appearance(out);
                if keyboard {
                    self.pending_focus = Some(Action::SetFont(font));
                }
            }
            Action::SetAccent(accent) => {
                self.accent = accent;
                self.persist_appearance(out);
                if keyboard {
                    self.pending_focus = Some(Action::SetAccent(accent));
                }
            }
            Action::ResetAppearance => {
                let defaults = Appearance::default();
                self.dark = defaults.dark;
                self.ui_font = defaults.font;
                self.accent = defaults.accent;
                self.font_size = defaults.font_size;
                self.animations = defaults.animations;
                out.push(Effect::SetDarkMode(self.dark));
                self.persist_appearance(out);
                if keyboard {
                    self.pending_focus = Some(Action::ResetAppearance);
                }
            }
            Action::Help => {
                self.overlay = Overlay::Help;
                self.hover = None;
            }
            Action::Focus => {
                self.focused_mode = !self.focused_mode;
                self.controls.clear();
                self.hover = None;
                self.feedback("Tab — вернуть / скрыть панели");
            }
            Action::Fit => self.fit(),
            Action::Actual => {
                let s = self.stage();
                self.zoom_at(1. / self.zoom, s.x + s.w / 2., s.y + s.h / 2.);
            }
            Action::ZoomIn | Action::ZoomOut => {
                let s = self.stage();
                self.zoom_at(
                    if a == Action::ZoomIn { 1.2 } else { 1. / 1.2 },
                    s.x + s.w / 2.,
                    s.y + s.h / 2.,
                );
            }
            Action::Tool(tool) => {
                self.switch_tool(tool);
                self.feedback(format!("{} · {}", tool.info().1, tool.info().2));
            }
            Action::ToolProperties => {
                if self.tool_has_properties() {
                    if self.tool_settings_visible() {
                        self.close_tool_settings();
                    } else {
                        self.overlay = Overlay::ToolProperties;
                        self.brush_detail = false;
                        self.focused_mode = false;
                        self.controls.clear();
                        self.hover = None;
                        self.pending_focus = if keyboard {
                            Some(if self.tool == Tool::Fill {
                                Action::Opacity
                            } else {
                                Action::Size
                            })
                        } else {
                            None
                        };
                    }
                }
            }
            Action::CloseToolProperties => self.close_tool_settings(),
            Action::ToolPanel(family) => {
                let was_open = self.tool_popup == Some(family);
                let tool = match family {
                    ToolPanel::Brush => Tool::Brush,
                    ToolPanel::Eraser => Tool::Eraser,
                    ToolPanel::Shapes => self.last_shape,
                };
                self.switch_tool(tool);
                self.brush_page = self.brush.kind.index() as usize / 4;
                if !was_open {
                    self.panel_scroll = 0.;
                }
                self.tool_popup = if was_open { None } else { Some(family) };
                self.controls.clear();
                self.hover = None;
                if keyboard {
                    self.pending_focus = Some(if was_open {
                        Action::ToolPanel(family)
                    } else {
                        self.selected_tool_option()
                    });
                }
            }
            Action::CloseToolPanel => {
                let family = self.tool_popup;
                self.close_tool_popup();
                self.pending_focus = family.map(Action::ToolPanel);
            }
            Action::Shape(tool) => {
                if matches!(tool, Tool::Line | Tool::Rectangle | Tool::Ellipse) {
                    self.switch_tool(tool);
                    self.tool_popup = Some(ToolPanel::Shapes);
                    if keyboard {
                        self.pending_focus = Some(Action::Shape(tool));
                    }
                }
            }
            Action::Mirror => {
                self.brush.mirror = !self.brush.mirror;
                self.feedback(if self.brush.mirror {
                    "Зеркало: штрих отражается по центру холста"
                } else {
                    "Зеркало выключено"
                });
            }
            Action::Value => {
                self.grayscale = !self.grayscale;
                self.feedback(if self.grayscale {
                    "Просмотр тона. Исходные цвета и PNG остаются цветными."
                } else {
                    "Цветной просмотр"
                });
            }
            Action::Grid => self.grid = !self.grid,
            Action::Brush(kind) => {
                let current = ToolSettings::from_brush(self.brush);
                let index = self.brush.kind.index() as usize;
                let next = kind.min(9) as usize;
                if self.tool == Tool::Eraser {
                    self.erase_presets[index] = current;
                    self.erase_presets[next].apply(&mut self.brush);
                } else {
                    self.paint_presets[index] = current;
                    self.paint_presets[next].apply(&mut self.brush);
                }
                if keyboard {
                    self.pending_focus = Some(Action::Brush(kind));
                }
            }
            Action::Size => out.push(Self::prompt(
                11,
                match self.tool {
                    Tool::Eraser => "Размер ластика",
                    Tool::Line | Tool::Rectangle | Tool::Ellipse => "Толщина контура",
                    _ => "Размер кисти",
                },
                "Размер в пикселях: от 1 до 512",
                format!("{:.0}", self.brush.size),
            )),
            Action::Opacity => out.push(Self::prompt(
                12,
                if self.tool == Tool::Eraser {
                    "Сила ластика"
                } else {
                    "Непрозрачность"
                },
                "Проценты: от 0 до 100",
                format!("{:.0}", self.brush.opacity * 100.),
            )),
            Action::LayerOpacity => out.push(Self::prompt(
                13,
                "Непрозрачность слоя",
                "Проценты: от 0 до 100",
                format!(
                    "{:.0}",
                    self.doc.layers[self.doc.active].opacity as f32 / 255. * 100.
                ),
            )),
            Action::Hex => out.push(Self::prompt(
                10,
                "Точный цвет",
                "Шесть символов HEX, например #365AD7",
                hex(self.brush.color),
            )),
            Action::SV => self.feedback("Стрелки: насыщенность и яркость. HEX — точный цвет."),
            Action::Hue => self.feedback("Стрелки: оттенок. HEX — точный цвет."),
            Action::Swatch(i) => {
                if let Some(c) = PALETTE.get(i) {
                    self.update_color(Color::from_hex(*c));
                }
            }
            Action::Recent(i) => {
                if let Some(c) = self.recent.get(i) {
                    self.update_color(*c);
                }
            }
            Action::AddLayer => match self
                .doc
                .add_layer(&format!("Слой {}", self.doc.layers.len() + 1))
            {
                Ok(_) => {
                    self.changed();
                    self.layer_scroll = 0;
                }
                Err(e) => self.error(e, out),
            },
            Action::Layer(i) => {
                if i < self.doc.layers.len() {
                    self.doc.active = i;
                    self.feedback(self.doc.layers[i].name.clone());
                }
            }
            Action::Visible(i) => {
                if let Some(layer) = self.doc.layers.get(i) {
                    let value = !layer.visible;
                    if self.doc.set_layer_visibility(i, value) {
                        self.changed();
                    }
                }
            }
            Action::Lock(i) => {
                if let Some(layer) = self.doc.layers.get(i) {
                    let value = !layer.locked;
                    if self.doc.set_layer_locked(i, value) {
                        self.changed();
                    }
                }
            }
            Action::Rename => out.push(Self::prompt(
                14,
                "Имя слоя",
                "Название слоя",
                self.doc.layers[self.doc.active].name.clone(),
            )),
            Action::Duplicate => match self.doc.duplicate_layer() {
                Ok(_) => {
                    self.changed();
                    self.layer_scroll = 0;
                }
                Err(e) => self.error(e, out),
            },
            Action::DeleteLayer => match self.doc.delete_layer() {
                Ok(()) => {
                    self.changed();
                    self.feedback("Слой удалён. Ctrl+Z — вернуть.");
                }
                Err(e) => self.error(e, out),
            },
            Action::Raise | Action::Lower => {
                if self.doc.move_layer(if a == Action::Raise { 1 } else { -1 }) {
                    self.changed();
                }
            }
            Action::NewPreset(i) => {
                let (w, h) = match i {
                    1 => (1080, 1080),
                    2 => (1200, 1600),
                    _ => (1200, 840),
                };
                self.new_width = w;
                self.new_height = h;
            }
            Action::NewWidth => out.push(Self::prompt(
                15,
                "Ширина холста",
                "Пиксели: от 1 до 4096",
                self.new_width.to_string(),
            )),
            Action::NewHeight => out.push(Self::prompt(
                16,
                "Высота холста",
                "Пиксели: от 1 до 4096",
                self.new_height.to_string(),
            )),
            Action::Create => match Document::with_background(
                self.new_width,
                self.new_height,
                Color::from_hex(0xfaf8f0),
            ) {
                Ok(mut doc) => {
                    doc.title = "Новый этюд".into();
                    doc.clear_history();
                    doc.mark_saved();
                    self.reset_document(doc, None, false);
                    self.clear_recovery();
                    self.feedback("Новый холст готов.");
                }
                Err(e) => self.error(e, out),
            },
            Action::Cancel => {
                self.overlay = Overlay::None;
                self.hover = None;
            }
        }
    }
    fn accept_prompt(&mut self, id: u32, value: Option<String>, out: &mut Vec<Effect>) {
        let Some(value) = value else {
            return;
        };
        match id {
            10 => {
                if let Some(c) = parse_hex(&value) {
                    self.update_color(c);
                } else {
                    self.error("Введите HEX в формате #RRGGBB. Например: #365AD7", out);
                }
            }
            11 | 12 | 13 => {
                let n = value.trim().replace(',', ".").parse::<f32>();
                let (min, max) = if id == 11 { (1., 512.) } else { (0., 100.) };
                match n {
                    Ok(n) if n.is_finite() && n >= min && n <= max => {
                        if id == 11 {
                            self.brush.size = n;
                        } else if id == 12 {
                            self.brush.opacity = n / 100.;
                        } else if self
                            .doc
                            .set_layer_opacity(self.doc.active, (n * 2.55).round() as u8)
                        {
                            self.changed();
                        }
                    }
                    _ => self.error(format!("Введите число от {min:.0} до {max:.0}."), out),
                }
            }
            17..=22 => {
                let action = match id {
                    17 => Action::Hardness,
                    18 => Action::Flow,
                    19 => Action::Spacing,
                    20 => Action::Angle,
                    21 => Action::Scatter,
                    _ => Action::FontSize,
                };
                let (min, max, _, _, _) = self.parameter_info(action);
                match value.trim().replace(',', ".").parse::<f32>() {
                    Ok(v) if v.is_finite() && v >= min && v <= max => self.set_parameter(action, v),
                    _ => self.error(format!("Введите число от {min:.0} до {max:.0}."), out),
                }
            }
            14 => match self.doc.rename_layer(self.doc.active, value.trim()) {
                Ok(()) => self.changed(),
                Err(e) => self.error(e, out),
            },
            15 | 16 => match value.trim().parse::<u32>() {
                Ok(n) if (1..=4096).contains(&n) => {
                    if id == 15 {
                        self.new_width = n
                    } else {
                        self.new_height = n
                    }
                }
                _ => self.error("Размер стороны должен быть от 1 до 4096 пикселей.", out),
            },
            _ => {}
        }
    }
    fn finish_drag(&mut self) {
        let d = std::mem::replace(&mut self.drag, Drag::None);
        match d {
            Drag::Stroke => {
                if self.doc.end_stroke() {
                    self.changed_raster();
                    if self.tool != Tool::Eraser {
                        self.remember();
                    }
                }
            }
            Drag::Shape { x, y, ex, ey } => {
                let b = self.brush_for_tool();
                let result = match self.tool {
                    Tool::Line => self.doc.draw_line(x, y, ex, ey, b),
                    Tool::Rectangle => self.doc.draw_rectangle(x, y, ex, ey, b),
                    Tool::Ellipse => self.doc.draw_ellipse(x, y, ex, ey, b),
                    _ => Ok(()),
                };
                match result {
                    Ok(()) => {
                        self.changed();
                        self.remember();
                    }
                    Err(e) => self.feedback(e),
                }
            }
            Drag::Slider {
                action: Action::LayerOpacity,
                ..
            } => {
                if self.doc.commit_edit() {
                    self.changed();
                }
            }
            _ => {}
        }
    }
    fn cancel_drag(&mut self) {
        let d = std::mem::replace(&mut self.drag, Drag::None);
        match d {
            Drag::Stroke => {
                self.doc.cancel_stroke();
                self.composite_dirty = true;
            }
            Drag::Slider {
                action: Action::LayerOpacity,
                ..
            } => {
                self.doc.cancel_edit();
                self.composite_dirty = true;
            }
            Drag::Slider {
                action, initial, ..
            } => self.set_parameter(action, initial),
            Drag::Color {
                initial, initial_h, ..
            } => {
                self.color_h = initial_h;
                self.update_color(initial);
            }
            Drag::Pan { ox, oy, .. } => {
                self.view_x = ox;
                self.view_y = oy;
            }
            _ => {}
        }
    }
    fn update_drag(&mut self, x: f32, y: f32, modifiers: Modifiers) {
        if self.canvas_obscured(x, y) && matches!(self.drag, Drag::Stroke | Drag::Shape { .. }) {
            self.finish_drag();
            return;
        }
        match self.drag {
            Drag::Stroke => {
                let (dx, dy) = self.doc_point(x, y);
                self.doc.continue_stroke(dx, dy);
            }
            Drag::Pan {
                x: ax,
                y: ay,
                ox,
                oy,
            } => {
                self.view_x = ox + x - ax;
                self.view_y = oy + y - ay;
            }
            Drag::Shape { x: ax, y: ay, .. } => {
                let (mut ex, mut ey) = self.doc_point(x, y);
                if modifiers.shift {
                    let (dx, dy) = (ex - ax, ey - ay);
                    if self.tool == Tool::Line {
                        let a = (dy.atan2(dx) / (std::f32::consts::PI / 4.)).round()
                            * (std::f32::consts::PI / 4.);
                        let d = dx.hypot(dy);
                        ex = ax + a.cos() * d;
                        ey = ay + a.sin() * d;
                    } else {
                        let d = dx.abs().max(dy.abs());
                        ex = ax + d * dx.signum();
                        ey = ay + d * dy.signum();
                    }
                }
                self.drag = Drag::Shape {
                    x: ax,
                    y: ay,
                    ex,
                    ey,
                };
            }
            Drag::Slider { action, rect, .. } => {
                let v = ((x - rect.x - 5.) / (rect.w - 10.)).clamp(0., 1.);
                match action {
                    a if a.is_parameter() => {
                        let (min, max, _, _, _) = self.parameter_info(a);
                        self.set_parameter(a, (min + v * (max - min)).round());
                    }
                    Action::LayerOpacity => {
                        self.doc
                            .set_layer_opacity(self.doc.active, (v * 255.).round() as u8);
                        self.composite_dirty = true;
                    }
                    _ => {}
                }
            }
            Drag::Color { action, rect, .. } => {
                if action == Action::SV {
                    self.color_s = ((x - rect.x) / rect.w).clamp(0., 1.);
                    self.color_v = (1. - (y - rect.y) / rect.h).clamp(0., 1.);
                } else {
                    self.color_h = (((x - rect.x) / rect.w).clamp(0., 1.) * 360.).rem_euclid(360.);
                }
                self.brush.color = hsv(self.color_h, self.color_s, self.color_v);
            }
            Drag::None => {}
        }
    }
    fn mouse_down(
        &mut self,
        x: f32,
        y: f32,
        button: MouseButton,
        modifiers: Modifiers,
        out: &mut Vec<Effect>,
    ) {
        self.pointer = (x, y);
        if self.closing_overlay.is_some() || self.closing_popup.is_some() {
            self.closing_overlay = None;
            self.closing_popup = None;
            self.overlay_motion.snap(self.overlay != Overlay::None);
            self.popup_motion.snap(self.tool_popup.is_some());
            return;
        }
        self.focus = None;
        self.pending_focus = None;
        self.finish_drag();
        let control = self
            .controls
            .iter()
            .rev()
            .find(|c| c.hit.contains(x, y))
            .cloned();
        if self.tool_popup_rect().is_some_and(|r| !r.contains(x, y)) {
            // A click outside dismisses the popup without leaving a paint mark.
            // Other toolbar controls remain reachable in the same click.
            let family_button = control.as_ref().is_some_and(|c| {
                c.enabled
                    && matches!(
                        c.action,
                        Action::ToolPanel(_) | Action::Size | Action::Opacity
                    )
            });
            if !family_button {
                self.close_tool_popup();
                if !control
                    .as_ref()
                    .is_some_and(|c| c.enabled && c.action != Action::NoOp)
                {
                    return;
                }
            }
        }
        if let Some(c) = control {
            if !c.enabled {
                return;
            }
            if button != MouseButton::Left {
                return;
            }
            match c.action {
                a if (a.is_parameter() || a == Action::LayerOpacity) && c.rect.h > 20. => {
                    if self.busy && c.action != Action::FontSize {
                        return;
                    }
                    let initial = if c.action == Action::LayerOpacity {
                        self.doc.layers[self.doc.active].opacity as f32 / 255.
                    } else {
                        self.parameter_value(c.action)
                    };
                    if c.action == Action::LayerOpacity {
                        self.doc.begin_edit();
                    }
                    self.drag = Drag::Slider {
                        action: c.action,
                        rect: c.rect,
                        initial,
                    };
                    self.update_drag(x, y, modifiers);
                }
                Action::SV | Action::Hue => {
                    self.drag = Drag::Color {
                        action: c.action,
                        rect: c.rect,
                        initial: self.brush.color,
                        initial_h: self.color_h,
                    };
                    self.update_drag(x, y, modifiers);
                }
                _ => self.activate(c.action, out),
            }
            return;
        }
        if self.overlay != Overlay::None {
            if self.overlay == Overlay::Settings {
                self.close_settings();
            } else if self.overlay == Overlay::ToolProperties {
                self.close_tool_settings();
            } else {
                self.overlay = Overlay::None;
                self.controls.clear();
                self.hover = None;
            }
            return;
        }
        if !self.stage().contains(x, y) || self.canvas_obscured(x, y) {
            return;
        }
        if button == MouseButton::Middle || self.space || self.tool == Tool::Hand {
            self.drag = Drag::Pan {
                x,
                y,
                ox: self.view_x,
                oy: self.view_y,
            };
            return;
        }
        if self.busy {
            return;
        }
        let (dx, dy) = self.doc_point(x, y);
        if dx < 0. || dy < 0. || dx >= self.doc.width as f32 || dy >= self.doc.height as f32 {
            return;
        }
        if button == MouseButton::Right || modifiers.alt || self.alt || self.tool == Tool::Picker {
            let c = self.doc.sample(dx as u32, dy as u32);
            if c.a > 0 {
                self.update_color(c);
                self.feedback(format!("Цвет взят с холста: {}", hex(c)));
            } else {
                self.feedback("В этой точке прозрачный пиксель.");
            }
            return;
        }
        if button != MouseButton::Left {
            return;
        }
        if !self.doc.can_paint() {
            self.feedback("Слой скрыт или заблокирован. Выберите доступный слой.");
            return;
        }
        match self.tool {
            Tool::Brush | Tool::Eraser => {
                match self.doc.begin_stroke(dx, dy, self.brush_for_tool()) {
                    Ok(()) => {
                        self.drag = Drag::Stroke;
                    }
                    Err(e) => self.error(e, out),
                }
            }
            Tool::Fill => {
                let mut c = self.brush.color;
                c.a = (self.brush.opacity * 255.).round() as u8;
                match self.doc.flood_fill(dx as u32, dy as u32, c, 24) {
                    Ok(true) => {
                        self.changed();
                        self.remember();
                    }
                    Ok(false) => {}
                    Err(e) => self.error(e, out),
                }
            }
            Tool::Line | Tool::Rectangle | Tool::Ellipse => {
                self.drag = Drag::Shape {
                    x: dx,
                    y: dy,
                    ex: dx,
                    ey: dy,
                }
            }
            _ => {}
        }
    }
    fn key(&mut self, code: u32, pressed: bool, repeat: bool, m: Modifiers, out: &mut Vec<Effect>) {
        if code == 18 {
            self.alt = pressed;
            return;
        }
        if code == 32 && (!pressed || self.focus.is_none()) {
            self.space = pressed;
            if !pressed && matches!(self.drag, Drag::Pan { .. }) {
                self.finish_drag();
            }
            return;
        }
        if !pressed {
            return;
        }
        if code == 27 {
            let cancelling_gesture = !matches!(self.drag, Drag::None);
            let family = self.tool_popup;
            let previous_overlay = self.overlay;
            self.cancel_drag();
            if !cancelling_gesture {
                self.overlay = Overlay::None;
                self.close_tool_popup();
                self.pending_focus = match previous_overlay {
                    Overlay::Settings => Some(Action::Settings),
                    Overlay::ToolProperties => Some(Action::ToolProperties),
                    Overlay::File => Some(Action::File),
                    _ => family.map(Action::ToolPanel),
                };
                self.controls.clear();
            }
            self.focus = None;
            self.hover = None;
            return;
        }
        if m.ctrl
            && code == 188
            && !repeat
            && matches!(
                self.overlay,
                Overlay::None | Overlay::Settings | Overlay::ToolProperties
            )
        {
            self.activate(Action::Settings, out);
            if self.overlay == Overlay::Settings {
                self.pending_focus = Some(self.settings_focus_action());
            }
            return;
        }
        if code == 115
            && !repeat
            && !m.ctrl
            && matches!(
                self.overlay,
                Overlay::None | Overlay::Settings | Overlay::ToolProperties
            )
        {
            self.activate(Action::ToolProperties, out);
            if self.tool_settings_visible() {
                self.pending_focus = Some(if self.tool == Tool::Fill {
                    Action::Opacity
                } else {
                    Action::Size
                });
            } else if self.tool_has_properties() {
                self.pending_focus = Some(Action::ToolProperties);
            }
            return;
        }
        if code == 118 && !repeat && !m.ctrl {
            self.activate(Action::Inspector(true), out);
            return;
        }
        if code == 117
            || (code == 9 && matches!(self.overlay, Overlay::Settings | Overlay::ToolProperties))
        {
            // F6 traverses controls; Tab also traverses an open settings dropdown.
            if self.controls.is_empty() {
                return;
            }
            let len = self.controls.len();
            let start = self.focus.unwrap_or(if m.shift { 0 } else { len - 1 });
            let mut next = start;
            for _ in 0..len {
                next = if m.shift {
                    (next + len - 1) % len
                } else {
                    (next + 1) % len
                };
                if self.controls[next].enabled {
                    break;
                }
            }
            self.focus = Some(next);
            self.feedback(self.controls[next].label.clone());
            return;
        }
        if self.overlay != Overlay::None {
            if self.overlay == Overlay::ToolProperties {
                if !m.ctrl && !m.alt && !repeat {
                    let tool = match code {
                        66 => Some(Tool::Brush),
                        69 => Some(Tool::Eraser),
                        71 => Some(Tool::Fill),
                        73 => Some(Tool::Picker),
                        72 => Some(Tool::Hand),
                        76 => Some(Tool::Line),
                        82 => Some(Tool::Rectangle),
                        79 => Some(Tool::Ellipse),
                        _ => None,
                    };
                    if let Some(tool) = tool {
                        self.activate(Action::Tool(tool), out);
                        return;
                    }
                }
                if [37, 38, 39, 40].contains(&code) {
                    if let Some(c) = self
                        .focus
                        .and_then(|i| self.controls.get(i))
                        .filter(|c| c.enabled)
                    {
                        let step = if code == 37 || code == 40 { -1. } else { 1. };
                        let step = step * if m.shift { 10. } else { 1. };
                        if !self.busy {
                            let action = c.action;
                            if action.is_brush_parameter() {
                                self.set_parameter(action, self.parameter_value(action) + step);
                            }
                        }
                    }
                    return;
                }
            }
            if self.overlay == Overlay::Settings && [37, 38, 39, 40].contains(&code) {
                let current = self
                    .focus
                    .and_then(|i| self.controls.get(i))
                    .map(|c| c.action);
                let step: isize = if code == 37 || code == 38 { -1 } else { 1 };
                let action = match current {
                    Some(Action::SetTheme(dark)) => Some(Action::SetTheme(!dark)),
                    Some(Action::FontSize) => {
                        self.set_parameter(Action::FontSize, self.font_size as f32 + step as f32);
                        None
                    }
                    Some(Action::SettingsTab(tab)) => Some(Action::SettingsTab(
                        (tab as isize + step).rem_euclid(3) as u8,
                    )),
                    Some(Action::SetAnimations(v)) => Some(Action::SetAnimations(!v)),
                    Some(Action::SetLanguage(language)) => {
                        let i = Language::ALL
                            .iter()
                            .position(|v| *v == language)
                            .unwrap_or(0) as isize;
                        Some(Action::SetLanguage(
                            Language::ALL[(i + step).rem_euclid(6) as usize],
                        ))
                    }
                    Some(Action::SetFont(font)) => {
                        let i = UiFont::ALL.iter().position(|f| *f == font).unwrap_or(0) as isize;
                        let delta = if code == 38 || code == 40 {
                            step * 2
                        } else {
                            step
                        };
                        Some(Action::SetFont(
                            UiFont::ALL
                                [(i + delta).rem_euclid(UiFont::ALL.len() as isize) as usize],
                        ))
                    }
                    Some(Action::SetAccent(accent)) => {
                        let i = Accent::ALL.iter().position(|a| *a == accent).unwrap_or(0) as isize;
                        Some(Action::SetAccent(
                            Accent::ALL[(i + step).rem_euclid(Accent::ALL.len() as isize) as usize],
                        ))
                    }
                    _ => None,
                };
                if let Some(action) = action {
                    self.activate(action, out);
                }
                return;
            }
            if self.overlay == Overlay::File && (code == 38 || code == 40) {
                self.menu_index = if code == 38 {
                    (self.menu_index + 7) % 8
                } else {
                    (self.menu_index + 1) % 8
                };
                self.focus = Some(self.menu_index);
                return;
            }
            if (code == 13 || code == 32) && self.focus.is_some() {
                if let Some(c) = self.focus.and_then(|i| self.controls.get(i)).cloned() {
                    self.activate(c.action, out);
                }
                return;
            }
            if self.overlay == Overlay::File && code == 13 {
                if let Some(c) = self.controls.get(self.menu_index).cloned() {
                    self.activate(c.action, out);
                }
                return;
            }
            return;
        }
        if let Some(i) = self.focus {
            if let Some(c) = self.controls.get(i).cloned() {
                if code == 13 || code == 32 {
                    self.activate(c.action, out);
                    return;
                }
                if [37, 38, 39, 40].contains(&code) {
                    let d = if code == 37 || code == 40 { -1. } else { 1. };
                    let k = if m.shift { 10. } else { 1. };
                    match c.action {
                        Action::Size => self.brush.size = (self.brush.size + d * k).clamp(1., 512.),
                        Action::Opacity => {
                            self.brush.opacity = (self.brush.opacity + d * k / 100.).clamp(0., 1.)
                        }
                        Action::LayerOpacity => {
                            if self.busy {
                                return;
                            }
                            let v = (self.doc.layers[self.doc.active].opacity as f32 + d * k * 2.55)
                                .clamp(0., 255.) as u8;
                            if self.doc.set_layer_opacity(self.doc.active, v) {
                                self.changed();
                            }
                        }
                        Action::Hue => {
                            self.color_h = (self.color_h + d * k).rem_euclid(360.);
                            self.brush.color = hsv(self.color_h, self.color_s, self.color_v);
                        }
                        Action::SV => {
                            if code == 37 || code == 39 {
                                self.color_s = (self.color_s + d * k / 100.).clamp(0., 1.);
                            } else {
                                self.color_v = (self.color_v + d * k / 100.).clamp(0., 1.);
                            }
                            self.brush.color = hsv(self.color_h, self.color_s, self.color_v);
                        }
                        _ => {}
                    }
                    return;
                }
            }
        }
        if repeat && !matches!(code, 219 | 221 | 187 | 189) {
            return;
        }
        let action = if m.ctrl {
            match code {
                78 => Some(if m.shift {
                    Action::AddLayer
                } else {
                    Action::New
                }),
                79 => Some(if m.shift {
                    Action::Import
                } else {
                    Action::Open
                }),
                83 => Some(if m.shift {
                    Action::SaveAs
                } else {
                    Action::Save
                }),
                69 if m.shift => Some(Action::Export),
                90 => Some(if m.shift { Action::Redo } else { Action::Undo }),
                89 => Some(Action::Redo),
                46 => Some(Action::DeleteLayer),
                222 => Some(Action::Grid),
                _ => None,
            }
        } else {
            match code {
                66 => Some(Action::Tool(Tool::Brush)),
                69 => Some(Action::Tool(Tool::Eraser)),
                71 => Some(Action::Tool(Tool::Fill)),
                73 => Some(Action::Tool(Tool::Picker)),
                72 => Some(Action::Tool(Tool::Hand)),
                76 => Some(Action::Tool(Tool::Line)),
                82 => Some(Action::Tool(Tool::Rectangle)),
                79 => Some(Action::Tool(Tool::Ellipse)),
                77 => Some(Action::Mirror),
                86 => Some(Action::Value),
                9 => Some(Action::Focus),
                48 | 96 => Some(Action::Fit),
                49 | 97 => Some(Action::Actual),
                187 | 107 => Some(Action::ZoomIn),
                189 | 109 => Some(Action::ZoomOut),
                112 => Some(Action::Help),
                113 => Some(Action::Rename),
                219 => {
                    self.brush.size = (self.brush.size / 1.15).round().max(1.);
                    None
                }
                221 => {
                    self.brush.size = (self.brush.size * 1.15).round().min(512.);
                    None
                }
                _ => None,
            }
        };
        if let Some(a) = action {
            self.activate(a, out);
        }
    }
    fn selected_file(&mut self, kind: FileKind, path: Option<PathBuf>, out: &mut Vec<Effect>) {
        let Some(mut path) = path else {
            self.pending = Pending::None;
            return;
        };
        if self.busy {
            self.feedback("Дождитесь окончания записи.");
            return;
        }
        match kind {
            FileKind::Project => {
                if self.file_is_save {
                    if path.extension().is_none() {
                        path.set_extension("portfolio");
                    }
                    self.save_to(path, out);
                } else {
                    self.feedback("Открываем проект…");
                    self.launch_io(
                        "portfolio-open",
                        move || IoMessage::Loaded {
                            result: Document::load(&path),
                            path,
                        },
                        out,
                    );
                }
            }
            FileKind::Image => self.queue_imports(vec![path], out),
            FileKind::Png => {
                if path.extension().is_none() {
                    path.set_extension("png");
                }
                self.export_to(path, out);
            }
        }
    }
}

impl NativeApp for PortfolioApp {
    fn preferred_language(&self) -> &'static str {
        self.language.key()
    }
    fn ui_font_scale(&self) -> f32 {
        self.font_size as f32 / 13.
    }
    fn needs_frequent_ticks(&self) -> bool {
        self.io.is_some() || self.auto_io.is_some()
    }
    fn wants_animation(&self) -> bool {
        self.motion_enabled()
            && (self.chrome_motion.active()
                || self.popup_motion.active()
                || self.overlay_motion.active())
    }

    fn ui_font(&self) -> UiFont {
        self.ui_font
    }

    fn resize(&mut self, width: u32, height: u32, scale: f32) {
        self.cancel_drag();
        self.focus = None;
        self.controls.clear();
        let old = self.stage();
        let (width, height) = platform::bounded_frame_size(width, height);
        self.width = width;
        self.height = height;
        self.scale = scale.max(0.5);
        if !self.initialized {
            self.initialized = true;
            self.fit();
        } else {
            let new = self.stage();
            self.view_x += (new.x + new.w / 2.) - (old.x + old.w / 2.);
            self.view_y += (new.y + new.h / 2.) - (old.y + old.h / 2.);
        }
        self.hover = None;
    }
    fn render(&mut self) -> Frame {
        if !self.initialized {
            self.initialized = true;
            self.fit();
        }
        self.controls.clear();
        let mut p = Painter::new(
            self.width,
            self.height,
            self.scale,
            Theme::with_accent(self.dark, self.accent).base,
        );
        p.font = self.ui_font;
        p.font_scale = self.font_size as f32 / 13.;
        p.language = self.language;
        self.draw_editor(&mut p);
        self.draw_closing_overlay(&mut p);
        p.frame
    }
    fn event(&mut self, event: Event) -> Vec<Effect> {
        let before = (self.overlay, self.tool_popup, self.focused_mode);
        let mut out = Vec::new();
        match event {
            Event::ReducedMotion(value) => {
                self.system_reduced_motion = value;
            }
            Event::FilesDropped { paths } => self.queue_imports(paths, &mut out),
            Event::MouseMove { x, y, modifiers } => {
                self.pointer = (x, y);
                self.alt = modifiers.alt;
                self.update_drag(x, y, modifiers);
                self.hover = self
                    .controls
                    .iter()
                    .enumerate()
                    .rev()
                    .find(|(_, c)| c.hit.contains(x, y))
                    .map(|(i, _)| i);
            }
            Event::MouseDown {
                x,
                y,
                button,
                modifiers,
            } => self.mouse_down(x, y, button, modifiers, &mut out),
            Event::MouseUp {
                x,
                y,
                button: _,
                modifiers,
            } => {
                self.update_drag(x, y, modifiers);
                self.finish_drag();
            }
            Event::Wheel {
                x,
                y,
                delta,
                modifiers,
            } => {
                if matches!(self.drag, Drag::None) && self.overlay == Overlay::None {
                    if self.tool_popup_rect().is_some_and(|r| r.contains(x, y)) {
                        // Popup padding and controls never pass wheel input to the canvas.
                    } else if self.panel() && self.right_panel_rect().contains(x, y) {
                        let maximum = if self.inspector_layers {
                            0.
                        } else {
                            (782. - self.h()).max(0.)
                        };
                        let off = self.panel_scroll.clamp(0., maximum);
                        let previous_layer = self.layer_scroll;
                        let row_top = if self.inspector_layers {
                            269.
                        } else {
                            513. - off
                        };
                        if y >= row_top {
                            let count = (((self.h() - 62. - row_top - 40.) / 44.).floor() + 1.)
                                .max(1.) as usize;
                            if delta < 0. {
                                self.layer_scroll = (self.layer_scroll + 1)
                                    .min(self.doc.layers.len().saturating_sub(count));
                            } else {
                                self.layer_scroll = self.layer_scroll.saturating_sub(1);
                            }
                        }
                        if !self.inspector_layers
                            && (y < row_top || previous_layer == self.layer_scroll)
                        {
                            self.panel_scroll = (off - delta * 48.).clamp(0., maximum);
                            self.focus = None;
                            self.hover = None;
                        }
                    } else if self.stage().contains(x, y) && !self.canvas_obscured(x, y) {
                        if modifiers.ctrl {
                            self.brush.size = (self.brush.size + delta * 2.).clamp(1., 512.);
                        } else {
                            self.zoom_at(1.15_f32.powf(delta), x, y);
                        }
                    }
                }
            }
            Event::Key {
                code,
                pressed,
                repeat,
                modifiers,
            } => self.key(code, pressed, repeat, modifiers, &mut out),
            Event::FocusLost => {
                self.cancel_drag();
                self.space = false;
                self.alt = false;
            }
            Event::CaptureLost => self.cancel_drag(),
            Event::Tick => self.tick(&mut out),
            Event::CloseRequested => self.request_replace(Pending::Quit, &mut out),
            Event::Confirmed { id, answer } => {
                if id == 1 {
                    match answer {
                        Answer::Yes => self.save(false, &mut out),
                        Answer::No => self.continue_pending(&mut out),
                        Answer::Cancel => self.pending = Pending::None,
                    }
                } else if id == 2 {
                    self.recover_available = false;
                    match answer {
                        Answer::Yes => {
                            self.preserve_recovery = true;
                            self.recovery_requested = true;
                            self.start_recovery(&mut out);
                        }
                        Answer::No => {
                            self.preserve_recovery = false;
                            self.clear_recovery();
                        }
                        Answer::Cancel => {
                            self.preserve_recovery = true;
                            self.feedback(
                                "Предыдущая резервная копия сохранена до следующего запуска.",
                            );
                        }
                    }
                }
            }
            Event::Prompted { id, value } => self.accept_prompt(id, value, &mut out),
            Event::FileSelected { kind, path } => self.selected_file(kind, path, &mut out),
            Event::Text(_) | Event::Paste(_) => {}
        }
        // Keep the file-dialog intention and native document title synchronized.
        for effect in &out {
            match effect {
                Effect::OpenFile(FileKind::Project) => self.file_is_save = false,
                Effect::SaveFile {
                    kind: FileKind::Project,
                    ..
                } => self.file_is_save = true,
                _ => {}
            }
        }
        if self.title_dirty {
            out.push(Effect::SetTitle(format!(
                "{}{} — Portfolio",
                if self.dirty() { "● " } else { "" },
                self.doc.title
            )));
            self.title_dirty = false;
        }
        if self.preferences_dirty && matches!(self.drag, Drag::None) {
            self.persist_appearance(&mut out);
            self.preferences_dirty = false;
        }
        self.sync_motion(before);
        for effect in &mut out {
            match effect {
                Effect::Message { title, message, .. } | Effect::Confirm { title, message, .. } => {
                    *title = self.language.translate(title);
                    *message = self.language.translate(message);
                }
                Effect::Prompt { title, label, .. } => {
                    *title = self.language.translate(title);
                    *label = self.language.translate(label);
                }
                _ => {}
            }
        }
        out
    }
}
impl PortfolioApp {
    pub fn new(persistent: bool) -> Self {
        let root = if persistent {
            std::env::var_os("LOCALAPPDATA")
                .map(PathBuf::from)
                .map(|p| p.join("Portfolio"))
        } else {
            None
        };
        let prefs = root.as_ref().map(|p| p.join("settings.txt"));
        let appearance = prefs
            .as_ref()
            .and_then(|p| fs::read_to_string(p).ok())
            .map(|s| Appearance::decode(&s))
            .unwrap_or_default();
        let recovery = root.as_ref().map(|p| p.join("recovery.portfolio"));
        let recover_available = recovery.as_ref().is_some_and(|p| p.is_file());
        let brush = Brush {
            color: Color::from_hex(0x365ad7),
            size: 24.,
            opacity: 1.,
            kind: BrushKind::Ink,
            erase: false,
            mirror: false,
            ..Brush::default()
        };
        let (h, s, v) = to_hsv(brush.color, 220.);
        Self {
            doc: demo::document(),
            dark: appearance.dark,
            ui_font: appearance.font,
            accent: appearance.accent,
            language: appearance.language,
            font_size: appearance.font_size,
            preferences_dirty: false,
            animations: appearance.animations,
            system_reduced_motion: false,
            motion_runtime: persistent,
            chrome_motion: Reveal::new(true),
            popup_motion: Reveal::new(false),
            overlay_motion: Reveal::new(false),
            closing_overlay: None,
            closing_popup: None,
            motion_hit_clip: None,
            motion_preview: None,
            settings_tab: 0,
            inspector_layers: false,
            brush_page: 0,
            brush_detail: false,
            paint_presets: BrushKind::ALL.map(|kind| ToolSettings::preset(kind, false)),
            erase_presets: BrushKind::ALL.map(|kind| ToolSettings::preset(kind, true)),
            brush_samples: vec![None; 20],
            tool: Tool::Brush,
            brush,
            tool_popup: None,
            paint_settings: ToolSettings::from_brush(brush),
            erase_settings: ToolSettings::preset(BrushKind::Ink, true),
            shape_settings: ToolSettings {
                kind: BrushKind::Ink,
                size: 4.,
                opacity: 1.,
                ..ToolSettings::preset(BrushKind::Ink, false)
            },
            last_shape: Tool::Rectangle,
            color_h: h,
            color_s: s,
            color_v: v,
            recent: Vec::new(),
            width: 1440,
            height: 940,
            scale: 1.,
            view_x: 0.,
            view_y: 0.,
            zoom: 1.,
            initialized: false,
            focused_mode: false,
            grayscale: false,
            grid: false,
            controls: Vec::new(),
            hit_clip: None,
            focus: None,
            pending_focus: None,
            hover: None,
            pointer: (-1., -1.),
            space: false,
            alt: false,
            overlay: Overlay::None,
            menu_index: 0,
            drag: Drag::None,
            layer_scroll: 0,
            panel_scroll: 0.,
            status: "Ваш первый этюд. Рисуйте поверх или создайте чистый холст.".into(),
            status_until: Instant::now() + Duration::from_secs(20),
            path: None,
            unsaved_origin: false,
            pending: Pending::None,
            file_is_save: false,
            new_width: 1200,
            new_height: 840,
            serial: 0,
            last_edit: Instant::now(),
            last_auto: Instant::now(),
            io: None,
            auto_io: None,
            document_id: 0,
            import_queue: VecDeque::new(),
            importing: false,
            import_failures: Vec::new(),
            import_count: 0,
            auto_revision: None,
            last_auto_saved: None,
            recovery_requested: false,
            preserve_recovery: recover_available,
            busy: false,
            prefs,
            recovery,
            recover_available,
            first_tick: true,
            composite: Vec::new(),
            composite_dirty: true,
            title_dirty: true,
        }
    }
    fn w(&self) -> f32 {
        self.width as f32 / self.scale
    }
    fn h(&self) -> f32 {
        self.height as f32 / self.scale
    }
    fn panel(&self) -> bool {
        !self.focused_mode
    }
    fn stage(&self) -> Rect {
        Rect::new(0., 64., self.w(), (self.h() - 64.).max(0.))
    }
    fn top_tools_rect(&self) -> Rect {
        let width = (self.w() - 96.).max(0.).min(724.);
        Rect::new((self.w() - width) / 2., 80., width, 48.)
    }
    fn tool_family_rect(&self, family: ToolPanel) -> Rect {
        let index = match family {
            ToolPanel::Brush => 0,
            ToolPanel::Eraser => 1,
            ToolPanel::Shapes => 2,
        };
        Rect::new(
            self.top_tools_rect().x + 8. + index as f32 * 40.,
            88.,
            36.,
            32.,
        )
    }
    fn tool_settings_button_rect(&self) -> Rect {
        Rect::new(self.top_tools_rect().x + 136., 88., 36., 32.)
    }
    fn tool_settings_visible(&self) -> bool {
        self.overlay == Overlay::ToolProperties && self.tool_has_properties()
    }
    fn tool_has_properties(&self) -> bool {
        ToolPanel::for_tool(self.tool).is_some() || self.tool == Tool::Fill
    }
    fn tool_properties_title(&self) -> &'static str {
        self.tool.info().1
    }
    fn tool_settings_rect(&self) -> Rect {
        let gear = self.tool_settings_button_rect();
        Rect::new(
            (gear.x + gear.w / 2. - 160.).clamp(16., (self.w() - 336.).max(16.)),
            136.,
            320.,
            if self.tool == Tool::Fill {
                168.
            } else if matches!(self.tool, Tool::Brush | Tool::Eraser) {
                420.
            } else {
                224.
            },
        )
    }
    fn close_tool_settings(&mut self) {
        self.overlay = Overlay::None;
        self.controls.clear();
        self.focus = None;
        self.hover = None;
        self.pending_focus = Some(Action::ToolProperties);
    }
    fn right_panel_rect(&self) -> Rect {
        Rect::new(self.w() - 304., 144., 288., (self.h() - 160.).max(0.))
    }
    fn settings_rect(&self) -> Rect {
        Rect::new((self.w() - 416.).max(16.), 72., 400., 496.)
    }
    fn close_settings(&mut self) {
        self.overlay = Overlay::None;
        self.controls.clear();
        self.focus = None;
        self.hover = None;
        self.pending_focus = Some(Action::Settings);
    }
    fn tool_popup_rect(&self) -> Option<Rect> {
        if self.focused_mode {
            return None;
        }
        self.tool_popup.map(|family| {
            let wide = family != ToolPanel::Shapes;
            let width = if wide { 464. } else { 380. };
            Rect::new(
                self.tool_family_rect(family)
                    .x
                    .clamp(16., (self.w() - width - 16.).max(16.)),
                136.,
                width,
                if wide { 96. } else { 68. },
            )
        })
    }
    fn canvas_obscured(&self, x: f32, y: f32) -> bool {
        !self.focused_mode
            && (self.top_tools_rect().contains(x, y)
                || self.right_panel_rect().contains(x, y)
                || (self.tool_settings_visible() && self.tool_settings_rect().contains(x, y))
                || self.tool_popup_rect().is_some_and(|r| r.contains(x, y)))
    }
    fn close_tool_popup(&mut self) {
        if self.tool_popup.take().is_some() {
            self.controls.clear();
            self.focus = None;
            self.pending_focus = None;
            self.hover = None;
        }
    }
    fn selected_tool_option(&self) -> Action {
        if matches!(self.tool, Tool::Line | Tool::Rectangle | Tool::Ellipse) {
            Action::Shape(self.tool)
        } else {
            Action::Brush(self.brush.kind.index())
        }
    }
    fn switch_tool(&mut self, tool: Tool) {
        let current = ToolPanel::for_tool(self.tool);
        let next = ToolPanel::for_tool(tool);
        if current != next {
            let settings = ToolSettings::from_brush(self.brush);
            match current {
                Some(ToolPanel::Brush) => self.paint_settings = settings,
                Some(ToolPanel::Eraser) => self.erase_settings = settings,
                Some(ToolPanel::Shapes) => self.shape_settings = settings,
                None => {}
            }
            let settings = match next {
                Some(ToolPanel::Brush) => self.paint_settings,
                Some(ToolPanel::Eraser) => self.erase_settings,
                Some(ToolPanel::Shapes) => self.shape_settings,
                None => ToolSettings::from_brush(self.brush),
            };
            settings.apply(&mut self.brush);
        }
        if next == Some(ToolPanel::Shapes) {
            self.last_shape = tool;
        }
        self.tool = tool;
        self.panel_scroll = self.panel_scroll.clamp(0., (782. - self.h()).max(0.));
        if self.overlay == Overlay::ToolProperties && !self.tool_has_properties() {
            self.close_tool_settings();
        }
        self.controls.clear();
        self.hover = None;
    }
    fn floating_surface(&mut self, p: &mut Painter, r: Rect, label: &str) {
        let t = Theme::with_accent(self.dark, self.accent);
        p.soft_shadow(r, 4., if self.dark { 0.14 } else { 0.10 });
        p.rounded(r, 4., t.surface);
        // Register beneath actual controls; blank padding must also consume input.
        self.control(r, Action::NoOp, label, false);
    }
    fn canvas(&self) -> Rect {
        Rect::new(
            self.view_x,
            self.view_y,
            self.doc.width as f32 * self.zoom,
            self.doc.height as f32 * self.zoom,
        )
    }
    fn doc_point(&self, x: f32, y: f32) -> (f32, f32) {
        ((x - self.view_x) / self.zoom, (y - self.view_y) / self.zoom)
    }
    fn fit(&mut self) {
        let s = self.stage();
        self.zoom = ((s.w - 80.) / self.doc.width as f32)
            .min((s.h - 80.) / self.doc.height as f32)
            .clamp(0.05, 16.);
        self.view_x = s.x + (s.w - self.doc.width as f32 * self.zoom) / 2.;
        self.view_y = s.y + (s.h - self.doc.height as f32 * self.zoom) / 2.;
    }
    fn zoom_at(&mut self, factor: f32, x: f32, y: f32) {
        let (dx, dy) = self.doc_point(x, y);
        self.zoom = (self.zoom * factor).clamp(0.05, 16.);
        self.view_x = x - dx * self.zoom;
        self.view_y = y - dy * self.zoom;
    }
    fn dirty(&self) -> bool {
        self.unsaved_origin || self.doc.is_dirty()
    }
    fn feedback(&mut self, text: impl Into<String>) {
        self.status = text.into();
        self.status_until = Instant::now() + Duration::from_secs(6);
    }
    fn changed(&mut self) {
        self.serial = self.serial.wrapping_add(1);
        self.last_edit = Instant::now();
        self.composite_dirty = true;
        self.title_dirty = true;
    }
    fn update_color(&mut self, c: Color) {
        self.brush.color = c;
        let (h, s, v) = to_hsv(c, self.color_h);
        self.color_h = h;
        self.color_s = s;
        self.color_v = v;
    }
    fn remember(&mut self) {
        let c = self.brush.color;
        self.recent.retain(|v| *v != c);
        self.recent.insert(0, c);
        self.recent.truncate(8);
    }
    fn brush_for_tool(&self) -> Brush {
        Brush {
            erase: self.tool == Tool::Eraser,
            ..self.brush
        }
    }
    fn reset_document(&mut self, doc: Document, path: Option<PathBuf>, unsaved: bool) {
        self.document_id = self.document_id.wrapping_add(1);
        if !unsaved {
            self.clear_recovery();
        }
        self.doc = doc;
        self.path = path;
        self.unsaved_origin = unsaved;
        self.drag = Drag::None;
        self.overlay = Overlay::None;
        self.close_tool_popup();
        self.pending = Pending::None;
        self.layer_scroll = 0;
        self.changed();
        self.fit();
        self.last_auto = Instant::now();
    }
    fn prompt(id: u32, title: &str, label: &str, value: String) -> Effect {
        Effect::Prompt {
            id,
            title: title.into(),
            label: label.into(),
            value,
        }
    }
    fn error(&mut self, e: impl Into<String>, out: &mut Vec<Effect>) {
        let e = e.into();
        self.feedback(&e);
        out.push(Effect::Message {
            title: "Portfolio".into(),
            message: e,
            error: true,
        });
    }
    fn request_replace(&mut self, pending: Pending, out: &mut Vec<Effect>) {
        self.cancel_drag();
        if self.busy {
            self.feedback("Дождитесь завершения сохранения.");
            return;
        }
        self.overlay = Overlay::None;
        self.pending = pending;
        if self.dirty() {
            out.push(Effect::Confirm{id:1,title:"Сохранить изменения?".into(),message:"Сохранить рисунок перед продолжением?\n\nДа — сохранить. Нет — продолжить без сохранения. Отмена — вернуться к рисунку.".into()});
        } else {
            self.continue_pending(out);
        }
    }
    fn continue_pending(&mut self, out: &mut Vec<Effect>) {
        let p = self.pending;
        self.pending = Pending::None;
        match p {
            Pending::New => {
                self.overlay = Overlay::New;
                self.focus = None;
            }
            Pending::Open => out.push(Effect::OpenFile(FileKind::Project)),
            Pending::Demo => {
                self.reset_document(demo::document(), None, false);
                self.feedback("Этюд открыт. Все элементы доступны на слоях.");
            }
            Pending::Quit => {
                self.clear_recovery();
                out.push(Effect::Quit);
            }
            Pending::None => {}
        }
    }
    fn save(&mut self, save_as: bool, out: &mut Vec<Effect>) {
        self.finish_drag();
        if self.busy {
            return;
        }
        if !save_as {
            if let Some(path) = self.path.clone() {
                self.save_to(path, out);
                return;
            }
        }
        out.push(Effect::SaveFile {
            kind: FileKind::Project,
            suggested_name: format!("{}.portfolio", self.doc.title),
        });
    }
    fn save_to(&mut self, path: PathBuf, out: &mut Vec<Effect>) {
        if self.busy {
            return;
        }
        match self.doc.snapshot_for_io() {
            Ok(doc) => {
                let serial = self.serial;
                self.feedback("Сохраняем проект…");
                self.launch_io(
                    "portfolio-save",
                    move || {
                        let result = doc.to_bytes().and_then(|bytes| {
                            document::atomic_write(&path, &bytes).map_err(|e| e.to_string())
                        });
                        IoMessage::Saved {
                            path,
                            serial,
                            result,
                        }
                    },
                    out,
                );
            }
            Err(e) => self.error(e, out),
        }
    }
    fn export_to(&mut self, path: PathBuf, out: &mut Vec<Effect>) {
        if self.busy {
            return;
        }
        match self.doc.snapshot_for_io() {
            Ok(doc) => {
                self.feedback("Экспортируем PNG…");
                self.launch_io(
                    "portfolio-export",
                    move || IoMessage::Exported(doc.export_png(&path)),
                    out,
                );
            }
            Err(e) => self.error(e, out),
        }
    }
    fn clear_recovery(&self) {
        if self.preserve_recovery {
            return;
        }
        if let Some(p) = &self.recovery {
            let _ = fs::remove_file(p);
        }
    }
    fn persist_appearance(&mut self, out: &mut Vec<Effect>) {
        let Some(path) = self.prefs.clone() else {
            return;
        };
        let appearance = Appearance {
            dark: self.dark,
            font: self.ui_font,
            accent: self.accent,
            language: self.language,
            font_size: self.font_size,
            animations: self.animations,
        };
        let result = (|| {
            if let Some(parent) = path.parent() {
                fs::create_dir_all(parent)?;
            }
            document::atomic_write(&path, appearance.encode().as_bytes())
        })();
        if let Err(error) = result {
            self.error(format!("Не удалось сохранить настройки: {error}"), out);
        }
    }
    fn tick(&mut self, out: &mut Vec<Effect>) {
        if self.first_tick
            && !self.busy
            && self.io.is_none()
            && self.auto_io.is_none()
            && matches!(self.drag, Drag::None)
        {
            self.first_tick = false;
            out.push(Effect::SetDarkMode(self.dark));
            if self.recover_available {
                out.push(Effect::Confirm{id:2,title:"Найден незавершённый этюд".into(),message:"Восстановить рисунок из резервной копии?\n\nДа — восстановить. Нет — удалить резервную копию. Отмена — оставить копию до следующего запуска.".into()});
            }
        }
        let received = self.io.as_ref().map(|rx| rx.try_recv());
        let msg = match received {
            Some(Ok(msg)) => Some(msg),
            Some(Err(mpsc::TryRecvError::Disconnected)) => {
                self.io = None;
                self.busy = false;
                self.importing = false;
                self.import_queue.clear();
                self.import_failures.clear();
                self.import_count = 0;
                self.pending = Pending::None;
                self.error("Фоновая операция прервана. Попробуйте ещё раз.", out);
                None
            }
            _ => None,
        };
        if let Some(msg) = msg {
            self.io = None;
            self.busy = false;
            match msg {
                IoMessage::Saved {
                    path,
                    serial,
                    result,
                } => match result {
                    Ok(()) => {
                        self.path = Some(path);
                        if serial == self.serial {
                            self.doc.mark_saved();
                            self.unsaved_origin = false;
                            self.clear_recovery();
                            self.feedback("Проект сохранён");
                            self.continue_pending(out);
                        } else {
                            self.pending = Pending::None;
                            self.feedback(
                                "Сохранён предыдущий снимок. Новые изменения ещё не сохранены.",
                            );
                        }
                        self.title_dirty = true;
                    }
                    Err(e) => {
                        self.pending = Pending::None;
                        self.error(format!("Не удалось сохранить проект: {e}"), out);
                    }
                },
                IoMessage::Exported(result) => match result {
                    Ok(()) => self.feedback("PNG сохранён. Проект со слоями сохраняется отдельно."),
                    Err(e) => self.error(format!("Не удалось экспортировать PNG: {e}"), out),
                },
                IoMessage::Loaded { path, result } => match result {
                    Ok(doc) => {
                        self.reset_document(doc, Some(path), false);
                        self.feedback("Проект открыт");
                    }
                    Err(e) => self.error(e, out),
                },
                IoMessage::Recovered(result) => match result {
                    Ok(doc) => {
                        self.preserve_recovery = false;
                        self.reset_document(doc, None, true);
                        self.feedback("Этюд восстановлен. Сохраните его в нужную папку.");
                    }
                    Err(e) => self.error(e, out),
                },
                IoMessage::Imported { path, result } => {
                    let result = result.and_then(|image| {
                        let name = path
                            .file_stem()
                            .map(|s| s.to_string_lossy().into_owned())
                            .unwrap_or_else(|| "Изображение".into());
                        self.doc
                            .add_image_layer(&name, image.width, image.height, &image.pixels)
                            .map(|_| ())
                    });
                    match result {
                        Ok(()) => {
                            self.import_count += 1;
                            self.changed();
                            self.inspector_layers = true;
                            self.focused_mode = false;
                            self.panel_scroll = 0.;
                            self.layer_scroll = 0;
                        }
                        Err(e) => {
                            let name = path
                                .file_name()
                                .unwrap_or_default()
                                .to_string_lossy()
                                .chars()
                                .take(120)
                                .collect::<String>();
                            self.import_failures.push(format!(
                                "{name}: {}",
                                self.language
                                    .translate(&e)
                                    .chars()
                                    .take(400)
                                    .collect::<String>()
                            ));
                        }
                    }
                    if self.doc.layers.len() >= document::MAX_LAYERS
                        && !self.import_queue.is_empty()
                    {
                        self.import_failures
                            .push(self.language.translate("Достигнут предел числа слоёв."));
                        self.import_queue.clear();
                    }
                    self.start_next_import(out);
                }
            }
        }
        let auto = self.auto_io.as_ref().map(|rx| rx.try_recv());
        match auto {
            Some(Ok((id, result))) => {
                self.auto_io = None;
                let revision = self.auto_revision.take();
                if id != self.document_id || !self.dirty() {
                    self.clear_recovery();
                } else if result.is_ok() {
                    self.last_auto_saved = revision;
                }
                if let Err(e) = result {
                    self.feedback(format!("Резервная копия не записана: {e}"));
                }
            }
            Some(Err(mpsc::TryRecvError::Disconnected)) => {
                self.auto_io = None;
                self.auto_revision = None;
                self.feedback("Резервная копия не записана: фоновая операция прервана.");
            }
            _ => {}
        }
        self.start_recovery(out);
        if !self.busy
            && self.io.is_none()
            && self.auto_io.is_none()
            && !self.preserve_recovery
            && !self.recover_available
            && self.dirty()
            && matches!(self.drag, Drag::None)
            && self.last_auto.elapsed() > Duration::from_secs(30)
            && self.last_edit.elapsed() > Duration::from_secs(3)
            && self.last_auto_saved != Some((self.document_id, self.serial))
        {
            if let Some(path) = self.recovery.clone() {
                self.last_auto = Instant::now();
                match self.doc.snapshot_for_io() {
                    Ok(doc) => {
                        let (tx, rx) = mpsc::channel();
                        let id = self.document_id;
                        let revision = (id, self.serial);
                        let worker = std::thread::Builder::new()
                            .name("portfolio-recovery-save".into())
                            .spawn(move || {
                                let result = (|| {
                                    if let Some(parent) = path.parent() {
                                        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
                                    }
                                    let bytes = doc.to_bytes()?;
                                    document::atomic_write(&path, &bytes).map_err(|e| e.to_string())
                                })();
                                let _ = tx.send((id, result));
                            });
                        match worker {
                            Ok(_) => {
                                self.auto_io = Some(rx);
                                self.auto_revision = Some(revision);
                            }
                            Err(e) => self.feedback(format!("Резервная копия не записана: {e}")),
                        }
                    }
                    Err(e) => self.feedback(format!("Резервная копия не записана: {e}")),
                }
            }
        }
    }
    fn control(&mut self, rect: Rect, action: Action, label: impl Into<String>, enabled: bool) {
        let clip = self
            .hit_clip
            .unwrap_or(Rect::new(0., 0., self.w(), self.h()));
        let clip = self.motion_hit_clip.map_or(clip, |m| clip.intersection(m));
        let x = rect.x.max(clip.x);
        let y = rect.y.max(clip.y);
        let right = (rect.x + rect.w).min(clip.x + clip.w);
        let bottom = (rect.y + rect.h).min(clip.y + clip.h);
        if right <= x || bottom <= y {
            return;
        }
        let hit = Rect::new(x, y, right - x, bottom - y);
        if self.pending_focus == Some(action) && enabled {
            self.focus = Some(self.controls.len());
            self.pending_focus = None;
        }
        self.controls.push(Control {
            rect,
            hit,
            action,
            label: label.into(),
            enabled,
        });
    }
    fn button(
        &mut self,
        p: &mut Painter,
        r: Rect,
        action: Action,
        label: &str,
        icon: Option<&str>,
        selected: bool,
        enabled: bool,
        primary: bool,
    ) {
        let t = Theme::with_accent(self.dark, self.accent);
        let index = self.controls.len();
        let hover = self.hover == Some(index);
        let focus = self.focus == Some(index);
        let bg = if primary {
            t.accent
        } else if selected {
            t.selected
        } else if hover && enabled {
            t.raised
        } else {
            t.surface
        };
        p.rounded(r, 4., bg);
        if selected || focus {
            let thickness = if focus { 1.5 } else { 1. };
            p.rounded(r, 4., t.accent);
            p.rounded(r.inset(thickness), 4. - thickness, bg);
        }
        let c = if !enabled {
            t.muted
        } else if primary {
            t.on_accent
        } else if selected {
            t.accent
        } else {
            t.text
        };
        if let Some(icon) = icon {
            p.icon(
                if label.is_empty() {
                    r
                } else {
                    Rect::new(r.x + 6., r.y, 28., r.h)
                },
                icon,
                c,
            );
        }
        if !label.is_empty() {
            let ir = if icon.is_some() {
                Rect::new(r.x + 34., r.y, r.w - 39., r.h)
            } else {
                r
            };
            p.text(ir, label, 12., c, primary, false, TextAlign::Center);
        }
        self.control(
            r,
            action,
            if label.is_empty() {
                format!("{:?}", action)
            } else {
                label.into()
            },
            enabled,
        );
    }
    fn icon_button(
        &mut self,
        p: &mut Painter,
        r: Rect,
        action: Action,
        icon: &str,
        tip: &str,
        selected: bool,
        enabled: bool,
    ) {
        let before = self.controls.len();
        self.button(p, r, action, "", Some(icon), selected, enabled, false);
        if self.controls.len() > before {
            if let Some(c) = self.controls.last_mut() {
                c.label = tip.into();
            }
        }
    }
    fn slider(
        &mut self,
        p: &mut Painter,
        r: Rect,
        action: Action,
        value: f32,
        max: f32,
        label: &str,
        display: String,
        enabled: bool,
    ) {
        let t = Theme::with_accent(self.dark, self.accent);
        p.label(r.x, r.y, r.w - 60., label, 12., t.muted);
        p.text(
            Rect::new(r.x + r.w - 64., r.y - 1., 64., 22.),
            display,
            12.,
            t.text,
            false,
            false,
            TextAlign::Right,
        );
        let track = Rect::new(r.x, r.y + 31., r.w, 4.);
        p.rounded(track, 2., t.border);
        p.rounded(
            Rect::new(track.x, track.y, track.w * (value / max).clamp(0., 1.), 4.),
            2.,
            if enabled { t.accent } else { t.muted },
        );
        let cx = track.x + track.w * (value / max).clamp(0., 1.);
        p.circle(cx, track.y + 2., 5., t.accent, true);
        p.circle(cx, track.y + 2., 2., t.on_accent, true);
        if self.focus == Some(self.controls.len()) {
            p.border(r.inset(-3.), t.accent);
        }
        self.control(
            Rect::new(r.x - 5., r.y + 20., r.w + 10., 26.),
            action,
            format!("{label}: стрелки — изменить, Enter — точное значение"),
            enabled,
        );
        self.control(
            Rect::new(r.x + r.w - 64., r.y, 64., 20.),
            action,
            format!("Точное значение: {label}"),
            enabled,
        );
    }
}

impl Action {
    fn is_brush_parameter(self) -> bool {
        matches!(
            self,
            Self::Size
                | Self::Opacity
                | Self::Hardness
                | Self::Flow
                | Self::Spacing
                | Self::Angle
                | Self::Scatter
        )
    }
    fn is_parameter(self) -> bool {
        self.is_brush_parameter() || self == Self::FontSize
    }
}
impl PortfolioApp {
    fn file_menu_rect(&self) -> Rect {
        Rect::new(
            20.,
            64.,
            344. + (self.font_size as f32 - 13.).max(0.) * 12.,
            344.,
        )
    }
    fn settings_focus_action(&self) -> Action {
        match self.settings_tab {
            1 => Action::SetFont(self.ui_font),
            2 => Action::SetLanguage(self.language),
            _ => Action::SetTheme(self.dark),
        }
    }
    fn brand_rect(&self) -> Rect {
        Rect::new(16., 10., 224., 44.)
    }
    fn dropdown_surface(&mut self, p: &mut Painter, r: Rect, anchor: f32, label: &str) {
        self.floating_surface(p, r, label);
        p.triangle_up(
            anchor.clamp(r.x + 12., r.x + r.w - 12.),
            r.y + 1.,
            8.,
            9.,
            Theme::with_accent(self.dark, self.accent).surface,
        );
    }
    fn brush_sample(mut settings: ToolSettings, color: u32) -> Vec<Color> {
        let Ok(mut doc) = Document::new(112, 40) else {
            return vec![Color::TRANSPARENT; 4480];
        };
        settings.size = settings.size.clamp(3., 22.);
        let mut brush = Brush {
            color: Color::from_hex(color),
            ..Brush::default()
        };
        settings.apply(&mut brush);
        let _ = doc.begin_stroke(12., 20., brush);
        for i in 1..=28 {
            let u = i as f32 / 28.;
            doc.continue_stroke(12. + 88. * u, 20. + (u * std::f32::consts::TAU).sin() * 5.);
        }
        doc.end_stroke();
        doc.composite()
    }
    fn parameter_info(&self, a: Action) -> (f32, f32, &'static str, u32, &'static str) {
        match a {
            Action::Size => (1., 512., "Размер", 11, "px"),
            Action::Opacity => (
                0.,
                100.,
                if self.tool == Tool::Eraser {
                    "Сила стирания"
                } else {
                    "Непрозрачность"
                },
                12,
                "%",
            ),
            Action::Hardness => (0., 100., "Жёсткость", 17, "%"),
            Action::Flow => (0., 100., "Подача краски", 18, "%"),
            Action::Spacing => (2., 200., "Интервал", 19, "%"),
            Action::Angle => (0., 360., "Угол", 20, "°"),
            Action::Scatter => (0., 100., "Разброс", 21, "%"),
            Action::FontSize => (11., 17., "Размер текста", 22, "px"),
            _ => (0., 1., "", 0, ""),
        }
    }
    fn parameter_value(&self, a: Action) -> f32 {
        match a {
            Action::Size => self.brush.size,
            Action::Opacity => self.brush.opacity * 100.,
            Action::Hardness => self.brush.hardness * 100.,
            Action::Flow => self.brush.flow * 100.,
            Action::Spacing => self.brush.spacing * 100.,
            Action::Angle => self.brush.angle,
            Action::Scatter => self.brush.scatter * 100.,
            Action::FontSize => self.font_size as f32,
            _ => 0.,
        }
    }
    fn set_parameter(&mut self, a: Action, value: f32) {
        if !value.is_finite() {
            return;
        }
        let (min, max, _, _, _) = self.parameter_info(a);
        let value = value.clamp(min, max);
        match a {
            Action::Size => self.brush.size = value,
            Action::Opacity => self.brush.opacity = value / 100.,
            Action::Hardness => self.brush.hardness = value / 100.,
            Action::Flow => self.brush.flow = value / 100.,
            Action::Spacing => self.brush.spacing = value / 100.,
            Action::Angle => self.brush.angle = value,
            Action::Scatter => self.brush.scatter = value / 100.,
            Action::FontSize => {
                self.font_size = value.round() as u16;
                self.preferences_dirty = true;
            }
            _ => {}
        }
    }
    fn parameter_slider(&mut self, p: &mut Painter, r: Rect, a: Action) {
        let (min, max, label, _, unit) = self.parameter_info(a);
        let value = self.parameter_value(a);
        self.slider(
            p,
            r,
            a,
            value - min,
            max - min,
            label,
            format!("{value:.0} {unit}"),
            !self.busy || a == Action::FontSize,
        );
    }
    fn changed_raster(&mut self) {
        self.serial = self.serial.wrapping_add(1);
        self.last_edit = Instant::now();
        self.title_dirty = true;
    }
    fn motion_enabled(&self) -> bool {
        self.motion_runtime && self.animations && !self.system_reduced_motion
    }
    fn motion_value(&self, key: u8) -> f32 {
        if let Some(value) = self.motion_preview {
            if key != 0 {
                return value;
            }
        }
        let motion = match key {
            0 => &self.chrome_motion,
            1 => &self.popup_motion,
            _ => &self.overlay_motion,
        };
        if self.motion_enabled() {
            motion.value()
        } else {
            motion.target()
        }
    }
    fn begin_reveal(&mut self, p: &mut Painter, r: Rect, key: u8) {
        let progress = self.motion_value(key);
        if progress < 0.999 {
            let clip = Rect::new(r.x - 18., r.y - 12., r.w + 36., (r.h + 32.) * progress);
            p.limit = Some(clip);
            self.motion_hit_clip = Some(clip);
        }
    }
    fn end_reveal(&mut self, p: &mut Painter) {
        p.limit = None;
        self.motion_hit_clip = None;
    }
    fn overlay_bounds(&self, overlay: Overlay) -> Rect {
        match overlay {
            Overlay::Settings => self.settings_rect(),
            Overlay::ToolProperties => self.tool_settings_rect(),
            Overlay::File => self.file_menu_rect(),
            _ => Rect::new(0., 64., self.w(), self.h() - 64.),
        }
    }
    fn sync_motion(&mut self, before: (Overlay, Option<ToolPanel>, bool)) {
        if before.0 != self.overlay {
            self.closing_overlay = if self.overlay == Overlay::None && before.0 != Overlay::None {
                Some(before.0)
            } else {
                None
            };
            if self.overlay != Overlay::None && before.0 != Overlay::None {
                self.overlay_motion.snap(false);
            }
            self.overlay_motion.set(self.overlay != Overlay::None);
        }
        if before.1 != self.tool_popup {
            self.closing_popup = if self.tool_popup.is_none() {
                before.1
            } else {
                None
            };
            if self.tool_popup.is_some() && before.1.is_some() {
                self.popup_motion.snap(false);
            }
            self.popup_motion.set(self.tool_popup.is_some());
        }
        self.chrome_motion.set(!self.focused_mode);
        if !self.motion_enabled() {
            self.chrome_motion.snap(!self.focused_mode);
            self.popup_motion.snap(self.tool_popup.is_some());
            self.overlay_motion.snap(self.overlay != Overlay::None);
            self.closing_overlay = None;
            self.closing_popup = None;
        }
        if !self.overlay_motion.active() && self.overlay_motion.target() == 0. {
            self.closing_overlay = None;
        }
        if !self.popup_motion.active() && self.popup_motion.target() == 0. {
            self.closing_popup = None;
        }
    }
    fn draw_popup_layer(&mut self, p: &mut Painter) {
        let actual = self.tool_popup;
        let Some(family) = actual.or(self.closing_popup) else {
            return;
        };
        let ghost = actual.is_none();
        let saved = if ghost {
            Some((
                self.controls.clone(),
                self.focus,
                self.hover,
                self.pending_focus,
            ))
        } else {
            None
        };
        self.tool_popup = Some(family);
        if let Some(r) = self.tool_popup_rect() {
            self.begin_reveal(p, r, 1);
            self.draw_tool_popup(p);
            self.end_reveal(p);
        }
        self.tool_popup = actual;
        if let Some((controls, focus, hover, pending)) = saved {
            self.controls = controls;
            self.focus = focus;
            self.hover = hover;
            self.pending_focus = pending;
        }
    }
    fn draw_animated_overlay(&mut self, p: &mut Painter) {
        self.begin_reveal(p, self.overlay_bounds(self.overlay), 2);
        self.draw_overlay(p);
        self.end_reveal(p);
    }
    fn draw_closing_overlay(&mut self, p: &mut Painter) {
        if self.overlay != Overlay::None {
            return;
        }
        let Some(overlay) = self.closing_overlay else {
            return;
        };
        let saved = (
            self.controls.clone(),
            self.focus,
            self.hover,
            self.pending_focus,
        );
        self.overlay = overlay;
        self.draw_animated_overlay(p);
        self.overlay = Overlay::None;
        self.controls = saved.0;
        self.focus = saved.1;
        self.hover = saved.2;
        self.pending_focus = saved.3;
    }
    /// Deterministic design previews never wait or sleep for an animation.
    pub fn set_preview_motion(&mut self, progress: f32) {
        self.motion_preview = Some(progress.clamp(0., 1.));
    }
}

impl PortfolioApp {
    fn launch_io<F>(&mut self, name: &str, job: F, out: &mut Vec<Effect>) -> bool
    where
        F: FnOnce() -> IoMessage + Send + 'static,
    {
        let (tx, rx) = mpsc::channel();
        match std::thread::Builder::new()
            .name(name.into())
            .spawn(move || {
                let _ = tx.send(job());
            }) {
            Ok(_) => {
                self.io = Some(rx);
                self.busy = true;
                true
            }
            Err(e) => {
                self.error(format!("Не удалось запустить фоновую операцию: {e}"), out);
                false
            }
        }
    }
    fn queue_imports(&mut self, paths: Vec<PathBuf>, out: &mut Vec<Effect>) {
        if paths.is_empty() {
            return;
        }
        if self.busy && !self.importing {
            self.feedback("Дождитесь окончания записи.");
            return;
        }
        if paths.len() + self.import_queue.len() + usize::from(self.busy) > 32 {
            self.error(
                "Можно добавить не более 32 изображений за одну операцию.",
                out,
            );
            return;
        }
        self.finish_drag();
        self.overlay = Overlay::None;
        self.close_tool_popup();
        if !self.importing {
            self.import_count = 0;
            self.import_failures.clear();
        }
        self.importing = true;
        self.import_queue.extend(paths);
        if !self.busy {
            self.start_next_import(out);
        }
    }
    fn start_next_import(&mut self, out: &mut Vec<Effect>) {
        if let Some(path) = self.import_queue.pop_front() {
            self.feedback("Добавляем изображения…");
            if !self.launch_io(
                "portfolio-import",
                move || IoMessage::Imported {
                    result: platform::load_image(&path),
                    path,
                },
                out,
            ) {
                self.import_queue.clear();
                self.importing = false;
                self.import_count = 0;
                self.import_failures.clear();
            }
        } else {
            self.importing = false;
            if self.import_failures.is_empty() {
                self.feedback(format!("Добавлено изображений: {}", self.import_count));
            } else {
                let errors = std::mem::take(&mut self.import_failures);
                self.error(
                    format!(
                        "{}\n\n{}",
                        self.language
                            .translate("Некоторые изображения не удалось импортировать."),
                        errors.join("\n")
                    ),
                    out,
                );
            }
            self.import_count = 0;
        }
    }
    fn start_recovery(&mut self, out: &mut Vec<Effect>) {
        if !self.recovery_requested || self.busy || self.io.is_some() || self.auto_io.is_some() {
            return;
        }
        self.recovery_requested = false;
        if let Some(path) = self.recovery.clone() {
            self.feedback("Восстанавливаем проект…");
            self.launch_io(
                "portfolio-recovery-open",
                move || IoMessage::Recovered(Document::load(&path)),
                out,
            );
        }
    }
}
